<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Video;
use App\Models\Tag;

class MorphManyController extends Controller
{
    public function morphmanytomany($id)
    {
      // $data = Video::with('tag')->where('id',$id)->get(); 
     // $data = Post::with('tag')->where('id',$id)->get(); 
      $data = Tag::with('post')->where('id',$id)->get(); 
     // $data = Tag::with(['post','video'])->where('id',$id)->get(); 
      dd($data);
    }
}
