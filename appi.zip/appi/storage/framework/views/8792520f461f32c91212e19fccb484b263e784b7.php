<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
</head>
<body>
    Click here<a href="/post">Hello i am child page</a>
</body>
</html><?php /**PATH /opt/lampp/htdocs/appi/resources/views/main.blade.php ENDPATH**/ ?>