<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\SingleActionController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\RegistrationController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */





Route::get('/basic', [PageController::class, 'home']);//1st way to call basic controller
//Route::get('/','App\Http\Controllers\PageController@home');//second way  to call basic controller

Route::get('/single', SingleActionController::class);//way to call single action controller

Route::resource('/resource', PhotoController::class);//way to call resource controller

Route::get('/register', [RegistrationController::class, 'index']);

Route::post('/register', [RegistrationController::class, 'register']);





//if we don't call the conroller then use below code



Route::get('/', function () {
    return view('welcome');
});
/*
Route::get('/chk', function () {
    return view('main');
});

Route::get('/post', function () {
    return view('app');
});
*/