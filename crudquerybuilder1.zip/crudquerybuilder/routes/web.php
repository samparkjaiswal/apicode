<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/register', [StudentController::class, 'index']);

Route::get('/display', [StudentController::class, 'show']);

Route::get('/update/{id}', [StudentController::class, 'edit'])->name('update.edit'); //named routing method

Route::get('/delete/{id}', [StudentController::class, 'destroy'])->name('destroy'); //named routing method(we take any name in named routing)




//Route::post('/register', [StudentController::class, 'create'])->name('register.create');// that is for named route

Route::post('/register', [StudentController::class, 'create']);

//Route::post('/edit/{id}', [StudentController::class, 'update'])->name('edit.update');

Route::put('/update/{id}', [StudentController::class, 'update'])->name('update.update'); //we also use put method to update data(in the api it is neccessary to explain for update put method)