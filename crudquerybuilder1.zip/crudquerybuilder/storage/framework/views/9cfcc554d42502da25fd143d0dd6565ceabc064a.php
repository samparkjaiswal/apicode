<!doctype html>
<html lang="en">
  <head>
    <title>Display Record</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <div class="container">

      
        
     
        <table class="table table-striped table-bordered table-hover">
            <thead class="text-center table-dark">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th colspan="2">Operation</th>
                </tr>
            </thead>

            <tbody class="text-center">
              <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($stu->name); ?></td>
                    <td><?php echo e($stu->email); ?></td>
                    <td><?php echo e($stu->address); ?></td>
                    <td><a href="<?php echo e(route('update.edit', ['id' => $stu->id])); ?>"><button class="btn btn-primary">Edit</button></a></td>
                    <td><a href="<?php echo e(route('destroy', ['id' => $stu->id])); ?>"><button class="btn btn-danger">Delete</button></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
      
    </div>
    
  </body>
</html><?php /**PATH /opt/lampp/htdocs/crudquerybuilder/resources/views/display.blade.php ENDPATH**/ ?>