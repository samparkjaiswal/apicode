<!doctype html>
<html lang="en">
  <head>
    <title>Crud Query Builder</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
    
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-12">

              <!-- if we do not pass any action parameter then form work also -->
         <!--     <form action="{{-- route('register.create') --}}" method="post" autocomplete="off"> -->
          
                <form action="" method="post" autocomplete="off"> 
                    @csrf

                    <div class="mb-3">
                        <div class="form-group">
                          <label for="">Name</label>
                          <input type="text" class="form-control" name="name" id="" aria-describedby="helpId" placeholder="">
                         
                        
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="form-group">
                          <label for="">Email</label>
                          <input type="email" class="form-control" name="email" id="" aria-describedby="helpId" placeholder="">
                         
                        
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="form-group">
                          <label for="">Password</label>
                          <input type="password" class="form-control" name="password" id="" aria-describedby="helpId" placeholder="">
                         
                        
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="form-group">
                          <label for="">Address</label>
                          <textarea name="address" id="" class="form-control"></textarea>
                         
                        
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success">Submit</button>

                </form>
            </div>
           
        </div>
    </div>
    
  </body>
</html>