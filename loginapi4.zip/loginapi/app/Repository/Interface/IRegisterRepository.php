<?php

namespace App\Repository\Interface;


use App\Repository\Interface\IGenericRepository;

interface IRegisterRepository extends IGenericRepository
{
    
    public function save(array $regi);
   
    public function attemptauthemail($emali, $password);
  
}