<?php
namespace App\Repository;

use App\Repository\GenericRepository;

use App\Repository\Interface\IRegisterRepository;

use App\Models\User;




class RegisterRepository extends GenericRepository implements IRegisterRepository
{
    public function model()
    {
        return User::class;
    }

    public function save(array $regi)
    {
        return $this->model->create($regi);
    }


    public function attemptauthemail($email, $password)
    {
        // dd($email,$password);
    

    $user = $this->where([
        'email' => $email,
        'password'=>$password
    ])->first();

    //dd($data);

    if (!$user) {
        
    //  echo "Wrong Username or Password!";
        return false;
    }
    else
    {
       // echo "Login Success";
        
       $user->token = $user->createToken('Api access token')->accessToken;

       

        return $user;

        
    }

 

    // $data->token = $data->createToken('Api access token')->accessToken;


   
        
    }




  

}