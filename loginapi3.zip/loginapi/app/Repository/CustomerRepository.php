<?php 
namespace App\Repository;


use App\Repository\GenericRepository;
use App\Repository\Interface\ICustomerRepository;

use App\Models\Customer;



class CustomerRepository extends GenericRepository implements ICustomerRepository
{
    public function model()
    {
        return Customer::class;
    }

    public function storeservice($data)
    {
        
       $que = [
        'servicename' => $data['name'],
               'serviceimage' => $data['image'],
              'servicedescription' => $data['description'],
             
             
             
       ];
       
        return $this->model->insert($que);
    }


    public function userservice()
    {
        $code = $this->model->all('*');
        return $code;
    }


    public function updateservice(array $editrow,$id)
    {
        
        $editdata = $this->model->find($id,'*');
      
        $data = $editdata->update($editrow);
       return $data;
    }



}