<?php

namespace App\Repository\Interface;


use App\Repository\Interface\IGenericRepository;

interface ICustomerRepository extends IGenericRepository
{
    
    public function storeservice($data);

    public function userservice();

    public function updateservice(array $editrow,$id);
  
}