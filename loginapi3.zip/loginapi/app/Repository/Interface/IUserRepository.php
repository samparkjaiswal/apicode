<?php

namespace App\Repository\Interface;


use App\Repository\Interface\IGenericRepository;

interface IUserRepository extends IGenericRepository
{
 
    public function disdata();

    public function insertservice($id);
  
        // public function ins(array $data);
}