<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use App\Service\Interface\IUserService;

use App\Service\UserService;

use App\Repository\Interface\IUserRepository;
use App\Repository\UserRepository;
use App\Repository\Interface\ICustomerRepository;
use App\Repository\CustomerRepository;
use App\Repository\Interface\IRegisterRepository;
use App\Repository\RegisterRepository;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(IUserService::class, UserService::class);
        $this->app->bind(IUserRepository::class, UserRepository::class);
        $this->app->bind(ICustomerRepository::class, CustomerRepository::class);
        $this->app->bind(IRegisterRepository::class, RegisterRepository::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
