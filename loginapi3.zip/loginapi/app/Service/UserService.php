<?php
namespace App\Service;

use App\Service\Interface\IUserService;
use App\Repository\Interface\IUserRepository;
use App\Repository\Interface\ICustomerRepository;
use App\Repository\Interface\IRegisterRepository;

use App\Helper\UserHelper;
use App\Helper\RegisterHelper;
use Illuminate\Http\Request;


class UserService implements IUserService
{
    public $userrepository;
    public $customerrepository;
    public $userHelper;

    public function __construct(IUserRepository $userrepository,ICustomerRepository $customerrepository,IRegisterRepository $registerrepository,UserHelper $userHelper,RegisterHelper $registerHelper)
    {
        $this->userrepository = $userrepository;
        $this->customerrepository = $customerrepository;
        $this->registerrepository = $registerrepository;

        $this->userHelper = $userHelper;
        $this->registerHelper = $registerHelper;
    }

  public function disservice()
  {
    return $this->userrepository->disdata();
  }

  public function saveservice($id)
  {
    $data = $this->userrepository->insertservice($id);

    return $this->customerrepository->storeservice($data);

   // return $send;

   // dd($data);
  }


  public function view()
  {
    $viu = $this->customerrepository->userservice();

    return $viu;
  }

  public function edit(Request $request,$id)
  {
   
   
    $editrow = $this->userHelper->User($request);
  

    return $this->customerrepository->updateservice($editrow,$id);

  
  }

  public function insert(Request $request)
  {
     $regi = $this->registerHelper->Userreg($request);

     return $this->registerrepository->save($regi);
     //dd($regi);
  }

  public function login(Request $request)
  {
    $user = $this->registerrepository->attemptauthemail($request->email, $request->password);
    
    return $user;
  }



//   public function insert(array $data)
//   {
//     $this->userrepository->ins($data);
//   }

 
}

