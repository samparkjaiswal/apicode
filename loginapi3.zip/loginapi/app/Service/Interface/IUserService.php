<?php

namespace App\Service\Interface;

use Illuminate\Http\Request;



interface IUserService
{
   public function disservice();

   public function saveservice($id);

   public function view();


   public function edit(Request $request,$id);

   public function insert(Request $request);

   public function login(Request $request);

//    public function insert(array $data);
   
}