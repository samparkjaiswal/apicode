<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Image;
use App\Models\Comment;

class ImageController extends Controller
{
    public function morphone($id)
    {

   

    //    $data = Post::with('images')->where('id',$id)->get(); //use first/get method but morphOne method return only single data which relate with id

      //    $data = Post::with('images')->where('id',$id)->first();

    $data = Comment::with('images')->where('id',$id)->first(); 

  //  $data = Image::with('imageab')->where('id',$id)->first();  //For if we use this method then we pass the argument(__Function__,'imageable_type', 'imageable_id') in Image model(middle table) which use we access the relationship data

      // dd($data);

      return $data;

    }


    public function morphoneTomany($id)
    {
     // $data = Post::with('imagesmany')->where('id',$id)->get(); 
      $data = Comment::with('imagesmany')->where('id',$id)->get(); 
      dd($data);
    }


    public function morphoneoFmany($id)
    {
     // $data = Post::with('imagesofmany')->where('id',$id)->get(); 
      $data = Comment::with('imagesofmany')->where('id',$id)->get(); 
      dd($data);
    }

    



 }
    


