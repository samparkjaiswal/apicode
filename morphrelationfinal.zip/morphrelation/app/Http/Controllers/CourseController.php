<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;

class CourseController extends Controller
{
    public function morphmanytomany($id)
    {
      // $data = Post::with('imagesofmany')->where('id',$id)->get(); 
      $data = Student::with('teach')->where('id',$id)->get(); 
      dd($data);
    }
}
