<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
class ProductController extends Controller
{
    public function usecollection()
    {
       // $data = Product::get();

       //collect is helper that will be return data
       
       //$data = collect([1,2,3,4,5,6,7,8,9]);

       //$data = collect([1,2,3,4,5,6,7,8,9])->sum();
       //$data = collect([1,2,3,4,5,6,7,8,9])->count();
       //$data = collect([1,2,3,4,5,6,7,8,9])->average(); //avg= total sum of element/total no of element
       //$data = collect([1,2,3,4,5,6,7,8,9])->max(); 
       //$data = collect([1,2,3,4,5,6,7,8,9])->min(); 
       //$data = collect([1,2,3,4,5,6,7,8,9])->take(4); //take method is use for collect data which value pass in this method

        //  $data1 = collect([1,2,3,4,5,6,7,8,9]); 
        //  $data2 = collect([9,10,11]);
         
        //  $data = $data1->concat($data2);  //for concate data

        //$data = $data1->concat($data2)->unique(); //it will concate data and by unique method also return unique data(not duplicate data)
            //here we chaning the method one then another method 

        // $data = $data1->concat($data2)->unique()->keys(); //it will return only keys
        // $data = $data1->concat($data2)->unique()->values(); //it will return only values
       
     //  dd($data);
      //  return $data;

    //   $data = collect([1,2,3,4,5,6,7,8,9])->contains(9); //contains method used for see that, data will persent or not in collection
   // $data = collect([1,2,3,4,5,6,7,8,9])->contains('9'); //it's return true because in default php is loose checking so it's compare only value not data so that reason it return true

//    $data = collect([1,2,3,4,5,6,7,8,9])->containsStrict('9');  //now it return false because the we use containStrict method that match value and also datatype of value



// $data = collect([1,2,3,4,5,6,7,8,9]); //this will be Illuminate\Support\Collection

// $data = Product::get(); //this will be Illuminate\Database\Eloquent\Collection
//both are in diffrent folder
//all the method Support\Collection will work also on Illuminate\Database\Eloquent\Collection

// $data = Product::get()->take(5);
// $data = Product::get()->take(5)->sum('quantity');  //it sum all (5) quantity and return result
// $data = Product::get()->take(5)->sum('pprice');  //it sum all (5) price and return result

// $data = Product::get()->take(5)->average('quantity'); // it will return average of quantity
// $data = Product::get()->take(5)->contains('quantity',4);  //it will check in quantity field in 5 record ,4 is available or not

// $data = Product::get()->first(); //it will return the first array data(row) of table

// $data = Product::get()->last(); //it will return last row data of table

// $data = Product::get()->map(function($product) {  //in will return on pname of procduct model using map method in collection
    // return $product->pname;
// });   //this map method is in support collection method

// $data = Product::get()->pluck('pname','id');  //it will similler work as map function and if we want to fetch id then pass second argument in this  //this pluck method is eloquent bluilder collection method(confusion there)

// $data = Product::get()->filter(function($product) {  //filter method is use for filter data on the given condition
    // return $product->pprice > 10000;
// });

// $data = Product::get()->where('pprice','>',10000); //similar as filter method 

// $data = Product::get()             //here we chaning multiple method and find data and add new attribute and result will show on that attribu
//     ->where('pprice','>',10000)
//     ->map(function($product) {
//         $product->totalPrice = $product->pprice * $product->quantity;

//         return $product;
//     });


// $data = Product::get()     
//     ->where('pprice','>',10000)
//     ->map(function($product) {
//         $product->totalPrice = $product->pprice * $product->quantity;

//         return $product;
//     })
//     ->sum('totalPrice');    //here also we chaning multiple method and fetch data and add new attribute and show result on that attribute


// $data = Product::get()
//         ->sortBy('pprice');   //it will sort the data and sortBy method bydefault sort data in asscending order
        //    ->sortByDesc('pprice') //it will return by data in descending order


//   $data = Product::get()
//         // ->sortBy('pprice') //it will return by default data in asscending order
//         ->sortByDesc('pprice') //it will return by data in descending order
//          ->values();   //if sortby method will bydefault not work then we use values method with sortBy which help sortBy method work correct
    //  dd($data);

    //  return $data;


    // $items = collect(['one' => 1, 'two' => 2]);

    // $items->map(function ($item, $key) {
    //     return $item * 2;    //in this case item will not change or not multiply
    // });

    // $items->transform(function ($item, $key) {
    //     return $item * 2;    //in this case item will  change or  multiply with data by 2 each element (if we use transform method)
    // });

    //Note:
    
    //in the object if we use map or transform the data will be change
    //because by default in php the object data always changed but array data will be not changed
    //then notice that

    // $items = Product::get()->take(2);

    // $items->map(function($product) {
    //     $product->quantity = $product->quantity * 2;  //when we deal with object  and use collection then data will be changed but when we //deal with array data then data will not change so carefully handle it 

    //     return $product;
    // });

//for solve this changing array with object

    //   $items = Product::get()->take(2);

    // $items->map(function($product) {

    //     $product = clone $product; //it will create new a new product instance and data will be not changed
    //     $product->quantity = $product->quantity * 2;  //when we deal with object  and use collection then data will be changed but when we ////deal with array data then data will not change so carefully handle it 
    //     //

    //     return $product;
    // });



    // dd($items);
    // return $items;


   // $items = Product::get()->take(2);

//  return    $items->map(function($product) {

//         return $product->pname;
//     });

//  $items = Product::get()->take(2)->map->pname;  //if want to do simple the then we also use only map fuction and it will perform a function in function as above function

// $items = Product::get()->filter->active;  //it perform a operation backend and if active =1/true then it only that data /or filter that data which active column value is 1  //it's simple way for finding and there longer way is below

// $items = Product::get()->filter(function($product) {
//     return $product->active;   //this is longer way of filter it also return same data where active column =1
// });
//        //these are higher ordered massages or method of collection
//     return $items;






    }



}
