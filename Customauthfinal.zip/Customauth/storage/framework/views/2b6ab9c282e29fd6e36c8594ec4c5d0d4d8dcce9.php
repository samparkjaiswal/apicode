<!doctype html>
<html lang="en">
  <head>
    <title>Dashboard</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <div class="container">
        <div class="row" style="margin-top:45px">
            <div class="col-md-6 offset-md-3">

                <?php if(Session::get('Success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('Success')); ?>

                </div>
                <?php endif; ?>

                <?php if(Session::get('fail')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('fail')); ?>

                </div>
                <?php endif; ?>
                
                <?php if(Session::get('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('status')); ?>

                </div>
                <?php endif; ?>

                <h4>Dashboard | Hello, <?php echo e(session('Username')); ?>  </h4><hr>

               <a href='<?php echo e(route('auth.register')); ?>'> <button class="btn btn-primary">Create User</button> </a><br><br>

                <table class="table table-hover">

                    <thead>
                        <th>Name</th>
                        <th>Email</th>
                        <th colspan="2">Operation</th>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                       
                        <tr>
                            <td><?php echo e($value->name); ?></td> <!-- Both way we access data -->
                            <td><?php echo e($value->email); ?></td>
                            <td><a href="<?php echo e(route('auth.user_edit', ['id' =>$value->id])); ?>"><button class="btn btn-warning">Edit</button></a></td>
                            <td><a href="<?php echo e(route('auth.user_delete', ['id' =>$value->id])); ?>"><button class="btn btn-danger">Delete</button></a></td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
                <a href="<?php echo e(route('auth.logout')); ?>"><button class="btn btn-info">Logout</button></a>
                <a href="<?php echo e(route('auth.changepass')); ?>">Change Password</a>
            </div>
        </div>
    </div>

  </body>
</html><?php /**PATH /opt/lampp/htdocs/Customauth/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>