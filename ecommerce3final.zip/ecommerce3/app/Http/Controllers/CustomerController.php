<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Ordermanage;

class CustomerController extends Controller
{
    public function cureg()
    {
        return view('/customer/customerreg');
    }

    public function culogin()
    {
        return view('/customer/customerlogin');
    }

    public function cuhome()
    {
         return redirect(route('user.carddisplay'));
     
    }

    public function dash()
    {
        return view('/admin/dash');
    }

    public function addproduct()
    {
      // return view('/admin/addproduct');
      return redirect(route('admin.disproduct'));
    }

   
 

    public function cuinsert(Request $request)
    {
        // $request->validate([

        //     'name' => 'required',
        //     'email' => 'required|email|unique:customers',
        //     'password' => 'required|min:5|max:12',
        //     'mobile' => 'required|min:10|max:12',
        //     'address' => 'required'
    
        //    ]);

           $customer = new Customer;

           $customer->name = $request->name;
           $customer->email = $request->email;
           $customer->password = $request->password;
           $customer->mobile = $request->mobile;
           $customer->address = $request->address;
            $customer->save();

    }

    public function login(Request $request)
    {
       

        $customer = Customer::where('email', '=' ,$request->email)->first();
        
       
       
        if($customer)
        {
          
          if($request->password == $customer->password)
          {
            
           
            $request->session()->put('Loginid',$customer->id);
            $request->session()->put('Name',$customer->name);
            $request->session()->put('Email',$customer->email);
            $request->session()->put('role',$customer->role);
            //return redirect(route('admin.dash'));
            if(session()->has('Loginid'))
            {
                if(session('role')==1)
                {
                     
                   
                    return view('/admin/dash');
                }   
                else
                {
                  
                 return redirect(route('user.carddisplay'));
               
                }
            }
       
            // return response()->json([ [1] ]);
          }
          else
          {
            
            return redirect()->back()->with('status','Wrong password!');
          }
        }
        else
        {
            // return response()->json([ [3] ]);
         
           return redirect()->back()->with('fail','Email not recognize!');
        }
      
     }


     public function logout()
     {
        if(session()->has('Loginid'))
        {
            session()->pull('Loginid');
            // return redirect(route('customer.home'));
            return redirect(route('user.carddisplay'));
        }
     }

     public function insertproduct(Request $request)
     {
        $product = new Product;

       

        //The function GetClientOriginalName() is used to retrieve the file's original name at the time of upload in laravel and that'll only be possible if the data is sent as array and not as a string.
        if($request->hasFile('file'))
        {
        
        $file =$request->file('file');
        // $orgfilename = $file->getClientOriginalName();
        $orgextension =$file->getClientOriginalExtension();

         // $files=  $request->file('file')->storeAs('upload',$filename);

        $filename = time() . '.' .$orgextension;
       
        $file->move(public_path('/images/upload'),$filename);

       
        $product->productname = $request->pname;
        $product->file= $filename;
        $product->productprice = $request->pprice;
        
        }
      
        $product->save();


     }

   

     public function displayproduct()
     {
        
       

          //The compact() function is used to convert given variable to to array in which the key of the array will be the name of the variable and the value of the array will be the value of the variable.
        
        $products = Product::all();

       $data=compact('products');
   
       return view('/admin/addproduct')->with($data);
     
     }


  
    public function carddisp()

    {
        
        $records = Product::all();

       

        $data=compact('records');
   

        if(session()->has('Loginid'))
        {
           
           $count= Cart::where('email',session()->get('Email'))->count();

           session()->put('count',$count);
          
           
             return view('/customer/home')->with($data);
        }
        else
        {
          
            return view('/customer/home',)->with($data);
        }
     }


      //add to cart

     public function addcart(Request $request,$proid)
     {
       // print_r($proid);
       if(session()->has('Loginid'))
       {

        $prod = Product::find($proid);

        $cart =new Cart;

        $cart->username = $request->session()->get('Name');
       
        $cart->productname = $prod->productname;
        $cart->productprice = $prod->productprice;
        $cart->productquantity = $request->quantity;

        $cart->email = $request->session()->get('Email');

        $cart->save();


        return redirect()->back()->with('cartsuccess','Item add into cart success');

      }
      else
      {
        return redirect(route('cus.login'));
      }


        //print_r($produ->productname);
        
     }   


     public function viewcart()
     {

         if(session()->has('Loginid'))
         {
        
        $carts= Cart::where('email',session()->get('Email'))->get();
        // echo "<pre>";
       
        // print_r($carts);
        // echo "</pre>";
        // die;


   
        
        return view('/customer/showcart',['carts' =>$carts]);
            
        }
     }

     public function deletecart($cartid)
     {
        $data = Cart::find($cartid)->delete(); 
        return redirect()->back(); 
     }



     public function delivery(Request $request,$orderid)
     {
    //  print_r($orderid);
      
      if(session()->has('Loginid'))
      {
        // print_r($orderid);
        // die;
      $cart = Cart::where('email',$orderid)->get();

      $order = new Ordermanage;
        $total =0;
      //For Fetch Multiple data(Cart Product data which user has added Cart) from database by email(which key name is order id) use Foreach loop(Display all Cart Product) and where method for comparing and get method for fetch all data 
      
      foreach($cart as $value)
      {

        // echo "<pre>";
        // print_r($value->productname);
        // echo "</pre>";
       

        //For Storing Multiple Cart Value in one row make An Array First and then call Implode method for Conversion all array into string and  stored into database table 

        //If We use Relationship then Relationship is better than instead this method
        
        $total += $value->productprice*$value->productquantity;
       
        $arr[] = $value->productname;
        $arr1[] = $value->productquantity;

         $order->productname = implode(',',$arr);
         
         $order->productquantity = implode(',',$arr1);
         
         
  
       }

       //Total Price Count
      //  echo "<pre>";
      //  echo $total;
      //  echo "</pre>";


      // $order->productname = $value->productname;
      // $order->productprice = $value->	productprice;
      // $order->productquantity = $value->productquantity;
      // $order->orderemail = $request->session()->get('Email');

       //for Total price store into database

      $order->productprice = $total;


      //Modal Form Data Inserted Into Database In Order Table
      

      $order->customername = $request->name;
      $order->mobile = $request->mobile;
      $order->city = $request->city;
      $order->pincode = $request->pincode;
      $order->address = $request->address;
      $order->orderemail = $request->session()->get('Email');

       $order->save();

      return redirect()->back()->with('ordersuccess','Item Ordered Successfully!');
     
        
      

      //  $order->customername = $request->name;

      //  $order->mobile = $request->mobile;
      //  $order->city = $request->city;
      //  $order->pincode = $request->pincode;
      //  $order->address = $request->address;
      //  $order->productname = $cart->productname;
      //  $order->productprice = $cart->productprice;
      //  $order->productquantity = $cart->quantity;

      //  $order->orderemail = $request->session()->get('Email');

      //  $order->save();

      //  return redirect()->back()->with('ordersuccess','Item order success');

     
      }
      else
      {
        return redirect(route('user.carddisplay'));
      }
      
     }


     public function ordermanage()
     {
        if(session()->has('Loginid'))
        {
          
          $ordermanage = Ordermanage::all();

        //  $datas= compact($ordermanage);
          // echo "<pre>";
          // print_r($ordermanage);
          // echo "</pre>";
          //  die;
          
          
          return view('/admin/ordermanage',['datas'=>$ordermanage]);
        }
        else
        {
          return view('/customer/customerlogin');
        }
     }


     public function search(Request $request)
     {
       if(session()->has('Loginid'))
       {

        //For Sarching the data we use php operator like and wildcard(% etc php operator) who search any chareceter(as a,b etc) which any name and any position(starting and ending any position match) belong and show
        
        $search = $request->search;
        $records = Product::where('productname','Like','%'.$search.'%')->get();
        return view('/customer/home',compact('records'));

      }
      else
      {
        return view('/customer/customerlogin');
      }

     }

    
}
