<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Twilio\Rest\Client;

class CallController extends Controller
{
    public function get_form()
    {
        return view("Call");
    }

    public function make_call(Request $req)
    {
        // print_r([$req->phone_number, $req->msg]);

        $accSid = env('ACCOUNT_SID');
        $accToken = env('AUTH_TOKEN');
        $num = env('NUMBER');

        $client = new Client($accSid, $accToken);

        // Message
        // $client->messages->create('+91' . $req->phone_number, ['from' => $num, 'body' => $req->msg]);

        // Call
        $client->account->calls->create('+91' . $req->phone_number, $num, ['url' => "http://demo.twilio.com/docs/voice.xml"]);
    }
}
