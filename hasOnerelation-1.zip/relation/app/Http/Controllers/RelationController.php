<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Bike;

class RelationController extends Controller
{
    public function show($id)
    {
   

      //  $bycus = Customer::find($id);
       
     //  $bybike = Bike::find($id)->customer;



     $bybike = Bike::with('customer')->where('id',$id)->first();  //use this method this is  write approach
      
      
       dd($bybike);


   // $bike = $bycus->bike;
     // dd($bike->bikename);
    //  $arr = [$bycus->id,$bycus->cusname,$bike->bikename];  //both way we access data using relationship

    //  $arr = [$bike->id,$bycus->cusname,$bike->bikename];  //both way we access data using relationship

      // dd($arr);
    
       
    }
}
