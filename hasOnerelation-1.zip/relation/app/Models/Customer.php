<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    protected $table = 'customers';
    protected $fillable = ['cusname'];

    public function bike()
    {
        //return $this->hasOne(Bike::class,'customer_id','id');
        return $this->hasOne('App\Models\Bike','customer_id','id');
    }
}
