<?php
namespace App\Repository;

use App\Repository\GenericRepository;
use App\Repository\Interface\IUserRepository;

use App\Models\Service;


class UserRepository extends GenericRepository implements IUserRepository
{
    public function model()
    {
        return Service::class;
    }

   

   

}