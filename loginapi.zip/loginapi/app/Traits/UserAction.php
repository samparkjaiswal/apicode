<?php
namespace App\Traits;

use Illuminate\Http\Request;
use App\Helper\UserHelper;
use App\Service\Interface\IUserService;



trait UserAction
{
    public $userservice;

    private $userHelper; 

    public function __construct(IUserService $userservice,UserHelper $userHelper)
    {
        $this->userservice = $userservice;
        
       $this->userHelper = $userHelper;

    }

   
  

 

   
}

