<?php

namespace App\Service\Interface;



interface IUserService
{
   
   
}