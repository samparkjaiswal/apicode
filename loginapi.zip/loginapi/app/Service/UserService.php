<?php
namespace App\Service;

use App\Service\Interface\IUserService;
use App\Repository\Interface\IUserRepository;

use App\Helper\UserHelper;


class UserService implements IUserService
{
    public $userrepository;
    private $userHelper;

    public function __construct(IUserRepository $userrepository,UserHelper $userHelper)
    {
        $this->userrepository = $userrepository;

        $this->userHelper = $userHelper;
    }

  

 
}

