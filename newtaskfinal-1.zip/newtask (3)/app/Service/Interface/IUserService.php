<?php

namespace App\Service\Interface;



use App\Http\Requests\V1 as V1Request;

use App\Http\Requests\V1\RegisterUserRequest;
use App\Http\Requests\V1\UpdateUserRequest;


interface IUserService
{
    public function insert(RegisterUserRequest $request);

    public function showdis();

    public function remove($id);



    public function edit(RegisterUserRequest $request,$id);

   
}