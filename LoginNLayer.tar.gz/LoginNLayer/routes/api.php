<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginUser;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::post('/register', [LoginUser::class, 'trait_register_user']);
Route::post('/login', [LoginUser::class, 'trait_login_user']);
//  API for ADD PRODUCTS TO TABLE
Route::post('/addproduct', [LoginUser::class, 'trait_add_product']);

Route::middleware(['api'])->group(function () {
    Route::post('/adduserproducts/{id}', [LoginUser::class, 'trait_user_add_product']);
    Route::put('/editproduct/{id}', [LoginUser::class, 'trait_user_edit_product']);
    Route::post('/viewproduct/{id}', [LoginUser::class, 'trait_user_view_product']);
});
