<?php

namespace Intersoft\Auth\App\Http\Requests\V1;
use Illuminate\Foundation\Http\FormRequest;

class RegisterWithInviteCode extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => 'nullable|email|unique:users,email',
            'phone_number' => 'required|string|regex:/^([0-9]+)$/|min:8|max:14',
            'name' => 'nullable|string|regex:/^([a-z A-Z]+)$/',
            'password' => 'sometimes|required|string|min:8|max:12|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%#*?&])[A-Za-z\d@$!%#*?&]{8,}$/',
            'invite_code'=>'required',
        ];
    }
    public function messages()
    {
        return [
            'email' => 'The email has already been taken.'

        ];
    }
}
