<?php

namespace App\Http\Request\V1;

use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;
use App\Trait\RequestFailedValidation;

class RegisterUserRequest extends FormRequest
{
    use RequestFailedValidation;
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|string|regex:/^([a-z A-Z]+)$/',
            'email' => 'required|email|string|unique:users',
            'password' => 'sometimes|string|min:8|max:12',
        ];
    }
    public function messages()
    {
        return [

            'address.*.city.string' => 'City must be string',
            'address.*.country.string' => 'Country must be string',
            'address.*.formatted_address.string' => 'Formatted_address must be string',
            'address.*.additional_info.string' => 'Additional_info must be string',
            'address.*.latitude.numeric' => 'Latitude must be numeric',
            'address.*.longitude.numeric' => 'Longitude must be numeric',
            'address.*.is_primary.numeric' => 'Primary address must be numeric',
            'address.*.pincode.numeric' => 'pincode must be numeric',
            'address.*.city.required' => 'City must be required',
            'address.*.country.required' => 'Country must be required',
            'address.*.formatted_address.required' => 'Formatted_address must be required',
            'address.*.latitude.required' => 'Latitude must be required',
            'address.*.longitude.required' => 'Longitude must be required',
            'address.*.longitude.required' => 'Longitude must be required',
            'address.*.is_primary.required' => 'Primary address must be requird',
            'address.*.pincode.required' => 'Pincode must be required',
            'address.*.address_type.required' => 'address type must be required',
            'phonenumber.unique' => 'This phone no is already registered'

        ];
    }
}
