<?php

namespace App\Http\Requests\V1;

use Illuminate\Foundation\Http\FormRequest;
use App\Trait\RequestFailedValidation;
use Illuminate\Validation\Rule;
use App\Enum\LoginEnum;

class LoginUserRequest extends FormRequest
{
    use RequestFailedValidation;
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => 'sometimes|required_if:type,==,' . LoginEnum::email,
            'phone_number' => 'nullable|required_if:type,==,' . LoginEnum::phone . '|required_if:type,==,' . LoginEnum::phoneWithOtp . '|min:8|max:12',
            'country_code' => 'nullable|required_with:phone_number',
            'password' => 'nullable|required_if:type,==,' . LoginEnum::email . '|required_if:type,==,' . LoginEnum::phone . '|string',
            'type' => 'required|integer|min:1|max:3',
            'token' => 'sometimes|boolean',
            'registration' => [
                'nullable',
                'numeric',
                Rule::in([0, 1]),
            ],
            'country_iso_code' => 'sometimes|required_with:phone_number|string'
        ];
    }
}
