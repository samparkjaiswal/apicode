<?php

namespace App\Http\Controllers;

use App\Trait\LoginTrait;
use Illuminate\Http\Request;

class LoginUser extends Controller
{
    use LoginTrait;
}
