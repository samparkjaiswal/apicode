<?php

namespace App\Http\Middleware;

use Exception;
//use App\Exceptions\BlockedUserException;
use App\Http\Resources\Handler;
use App\Exceptions\SuccessException;
// use App\Exceptions\BadRequestException;
use Intersoft\Auth\App\Traits\APIResponse;
use App\Exceptions\RecordNotFoundException;
use Illuminate\Auth\AuthenticationException;
use Intersoft\Auth\App\Exceptions\BadRequestException;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
*
* Middleware that tries to automatically transform the data provided
* that is returned in the form of direct model
*/
class ResourceHandler
{
use APIResponse;
private $handler;

public function __construct(Handler $handler) //)
{
$this->handler = $handler;
}


public function handle($request, \Closure $next, $guard = null)
{
try {
$response = $next($request);
// Having the `original` property means that we have the models and
// the response can be tried to transform
if (property_exists($response, 'original')) {
// Check if response contains exception
if(is_array($response->original) && isset($response->original['exception'])){
return $this->throwExceptionByKeyAndValue($response->original['exception'], $response->original['message']);
}
// Transform based on model and reset the content
if (is_string($response->original))
return $this->reponseSuccess([], $response->original);
else
return $this->reponseSuccess($this->handler->transformModel($response->original));
}
} catch (SuccessException $ex) {
return $this->reponseSuccess($ex->getData(), $ex->getMessage(), $ex->getStatusCode());
} catch (AuthenticationException $ex) {
return $this->respondUnauthorized();
} catch (BadRequestException $ex) {
return $this->respondInvalidParameters($ex->getMessage());
} catch (ExceptionsBadRequestException $ex) {
return $this->respondInvalidParameters($ex->getMessage());
} catch (RecordNotFoundException $ex) {
return $this->respondNotFound($ex->getMessage());
} catch (Exception $ex) {
return $this->respondInternalError($ex->getMessage());
}
}

public function terminate($request, $response)
{
}

public function throwExceptionByKeyAndValue($exception, $message){
$response['data']="";
$response['message']=$message;
if(strpos($exception, '\BadRequestException')){
$response['status_code']=400;
return response()->json($response,400);
}
elseif(strpos($exception, '\AuthenticationException')){
$response['status_code']=401;
return response()->json($response,401);
}
elseif(strpos($exception, '\SuccessException')){
$response['status_code']=200;
return response()->json($response,200);
}
elseif(strpos($exception, '\ExceptionsBadRequestException')){
$response['status_code']=200;
return response()->json($response,200);
}
elseif(strpos($exception, '\RecordNotFoundException')){
$response['status_code']=404;
return response()->json($response,404);
}
elseif(strpos($exception, '\Exception')){
$response['status_code']=500;
return response()->json($response,500);
}
$response['status_code']=500;
return response()->json($response,500);
}
}