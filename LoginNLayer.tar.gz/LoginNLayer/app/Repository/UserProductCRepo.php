<?php

namespace App\Repository;

use App\Models\SelectedDataModel;
use App\Repository\GenericRepository;
use App\Repository\Interface\UserProductIRepo;

class UserProductCRepo extends GenericRepository implements UserProductIRepo
{
    public function model()
    {
        return SelectedDataModel::class;
    }

    public function user_add_product($data)
    {
        $userid = auth('api')->user()->id;
        $data = [
            'userid' => $userid,
            'productname' => $data['productname'],
            'price' => $data['price'],
        ];
        return $this->model->insert($data);
    }

    public function user_view_product($id)
    {
        $userid = auth('api')->user()->id;
        $prods = $this->model->where('userid', $userid)->get();
        return $prods;
    }

    public function user_edit_product($data)
    {
        $userid = auth('api')->user()->id;
        $data = [
            'productname' => $data['productname'],
            'price' => $data['price'],
        ];
        return $this->model->where('userid', $userid)->first()->update($data);
    }
}
