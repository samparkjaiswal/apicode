<?php

namespace App\Repository\Interface;

interface RepositoryInterface
{
    public function repository_add_product();
    public function repository_view_product();
    public function repository__edit_product();
}
