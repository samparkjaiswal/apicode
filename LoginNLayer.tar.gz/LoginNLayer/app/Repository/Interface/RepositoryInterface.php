<?php

namespace App\Repository\Interface;

interface RepositoryInterface
{
    public function repo_register_user($data);
    public function repo_login_user($email, $password);
}
