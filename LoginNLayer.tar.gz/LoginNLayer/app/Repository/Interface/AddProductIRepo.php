<?php

namespace App\Repository\Interface;


interface AddProductIRepo
{
    public function  repo_add_product($data);
    public function get_product_detail($id);
}
