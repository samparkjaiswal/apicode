<?php

namespace App\Repository\Interface;


interface UserProductIRepo
{
    public function user_add_product($data);
    public function user_view_product($id);
    public function user_edit_product($id);
}
