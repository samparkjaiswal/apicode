<?php

namespace App\Repository;

use App\Model;
use App\Repository\Interface\RepositoryInterface;
use App\Repository\GenericRepository;

class RepositoryClass extends GenericRepository implements RepositoryInterface
{

    public function model()
    {
        return Student::class;
    }

    //Functions
    public function repository_add_product()
    {
    }
    public function repository_view_product()
    {
    }
    public function repository__edit_product()
    {
    }
}
