<?php

namespace App\Repository;

use App\Model;
use App\Models\User;
use App\Repository\Interface\RepositoryInterface;
use App\Repository\GenericRepository;

class RepositoryClass extends GenericRepository implements RepositoryInterface
{

    public function model()
    {
        return User::class;
    }

    //Functions
    public function repo_register_user($data)
    {
        // dd('repo');
        return $this->model->create($data);
    }

    public function repo_login_user($email, $password)
    {
        $user = $this->where(['email' => $email, 'password' => $password])->first();
        // dd($user);
        if (!$user) {
            return response(['message' => 'User not found'], 401);
        } else {
            $user->token = $user->createToken('ApiToken')->accessToken;
            return $user;
        }
    }
}
