<?php

namespace App\Repository;

use App\Repository\Interface\AddProductIRepo;
use App\Models\ProductDataModel;
use App\Repository\GenericRepository;

class AddProductCRepo extends GenericRepository implements AddProductIRepo
{
    public function model()
    {
        return ProductDataModel::class;
    }

    public function repo_add_product($data)
    {
        return $this->model->create($data);
    }

    public function get_product_detail($id)
    {
        return $this->model->find($id);
    }
}
