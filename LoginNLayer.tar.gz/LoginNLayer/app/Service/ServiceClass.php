<?php

namespace App\Service;

use App\Service\Interface\ServiceInterface;
use App\Repository\Interface\RepositoryInterface;
use App\Helper\UserHelper;

class ServiceClass implements ServiceInterface
{
    //Variables
    public $riobj;
    public $uhobj;

    //Functions
    public function __contruct(RepositoryInterface $riobj, UserHelper $uhobj)
    {
        $this->riobj = $riobj;
        $this->uhobj = $uhobj;
    }

    public function service_add_product()
    {
    }
    public function service_view_product()
    {
    }
    public function service__edit_product()
    {
    }
}
