<?php

namespace App\Service;

use Illuminate\Http\Request;
use App\Http\Request\V1\RegisterUserRequest;

use App\Service\Interface\ServiceInterface;
use App\Repository\Interface\RepositoryInterface;
use App\Repository\Interface\AddProductIRepo;
use App\Repository\Interface\UserProductIRepo;

use App\Helper\UserHelper;
use App\Helper\APUserHelper;

class ServiceClass implements ServiceInterface
{
    //Variables
    public $riobj;
    public $uhobj;
    public $apuhobj;
    public $aprepoobj;
    public $upobj;

    //Functions
    public function __construct(RepositoryInterface $riobj, UserHelper $uhobj, APUserHelper $apuhobj, AddProductIRepo $aprepoobj, UserProductIRepo $upobj)
    {
        $this->riobj = $riobj;
        $this->uhobj = $uhobj;
        $this->apuhobj = $apuhobj;
        $this->aprepoobj = $aprepoobj;
        $this->upobj = $upobj;
    }

    public function service_register_user(RegisterUserRequest $req)
    {
        // dd($req);
        $data = $this->uhobj->GetData($req);
        return $this->riobj->repo_register_user($data);
    }

    public function service_login_user(Request $req)
    {
        return $this->riobj->repo_login_user($req->email, $req->password);
    }

    public function service_add_product(Request $req)
    {
        $data = $this->apuhobj->GetAPData($req);
        return $this->aprepoobj->repo_add_product($data);
    }

    public function service_user_add_product($id)
    {
        $data = $this->aprepoobj->get_product_detail($id);
        return $this->upobj->user_add_product($data);
    }

    public function service_view_product($id)
    {
        return $this->upobj->user_view_product($id);
    }

    public function service_edit_product($id)
    {
        $data = $this->aprepoobj->get_product_detail($id);
        return $this->upobj->user_edit_product($data);
    }
}
