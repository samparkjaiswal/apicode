<?php

namespace App\Service\Interface;

interface ServiceInterface
{
    public function service_add_product();
    public function service_view_product();
    public function service__edit_product();
}
