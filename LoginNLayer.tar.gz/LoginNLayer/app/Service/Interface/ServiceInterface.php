<?php

namespace App\Service\Interface;

use Illuminate\Http\Request;
use App\Http\Request\V1\RegisterUserRequest;

interface ServiceInterface
{
    public function service_register_user(RegisterUserRequest $req);
    public function service_login_user(Request $req);
    public function service_add_product(Request $req);
    public function service_user_add_product($id);
    public function service_view_product($id);
    public function service_edit_product($id);
}
