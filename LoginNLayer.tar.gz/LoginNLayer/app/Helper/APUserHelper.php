<?php

namespace App\Helper;

class APUserHelper
{
    public function GetAPData($req)
    {
        return [
            'username' => $req->username,
            'productname' => $req->productname,
            'price' => $req->price,
        ];
    }
}
