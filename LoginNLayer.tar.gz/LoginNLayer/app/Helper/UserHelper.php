<?php

namespace App\Helper;

class UserHelper
{
    public function GetData($req)
    {
        return [
            'name' => $req->name,
            'email' => $req->email,
            'password' => $req->password
        ];
    }
}
