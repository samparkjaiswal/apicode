<?php

namespace App\Helper;

use Illuminate\Http\Request;


class UserHelper
{
    public function GetData($req)
    {
        return [
            'name' => $req->name,
            'email' => $req->email,
            'phonenumber' => $req->phonenumber
        ];
    }
}
