<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SelectedDataModel extends Model
{
    use HasFactory;
    protected $table = 'selectedproduct';
    protected $fillable = ['userid', 'productname', 'price'];
}
