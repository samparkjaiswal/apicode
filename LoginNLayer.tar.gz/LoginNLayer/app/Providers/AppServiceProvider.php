<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

// Interface
use App\Service\Interface\ServiceInterface;
use App\Repository\Interface\RepositoryInterface;
use App\Repository\Interface\AddProductIRepo;
use App\Repository\Interface\UserProductIRepo;


// Class
use App\Service\ServiceClass;
use App\Repository\RepositoryClass;
use App\Repository\AddProductCRepo;
use App\Repository\UserProductCRepo;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(ServiceInterface::class, ServiceClass::class);
        $this->app->bind(RepositoryInterface::class, RepositoryClass::class);
        $this->app->bind(AddProductIRepo::class, AddProductCRepo::class);
        $this->app->bind(UserProductIRepo::class, UserProductCRepo::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
