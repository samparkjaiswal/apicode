<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use App\Service\Interface\ServiceInterface;
use App\Repository\Interface\RepositoryInterface;
use App\Service\ServiceClass;
use App\Repository\RepositoryClass;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(ServiceInterface::class, ServiceClass::class);
        $this->app->bind(RepositoryInterface::class, RepositoryClass::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
