<?php

namespace App\Trait;

use Illuminate\Http\Request;
use App\Http\Request\V1\RegisterUserRequest;
use App\Service\Interface\ServiceInterface;

trait LoginTrait
{
    //Variables
    public $obj;

    //Functions
    public function __construct(ServiceInterface $obj)
    {
        $this->obj = $obj;
    }

    public function trait_register_user(RegisterUserRequest $req)
    {
        return $this->obj->service_register_user($req);
    }

    public function trait_login_user(Request $req)
    {
        return $this->obj->service_login_user($req);
    }

    public function trait_add_product(Request $req)
    {
        return $this->obj->service_add_product($req);
    }

    public function trait_user_add_product($id)
    {
        return $this->obj->service_user_add_product($id);
    }

    public function trait_user_edit_product($id)
    {
        return $this->obj->service_edit_product($id);
    }

    public function trait_user_view_product($id)
    {
        return $this->obj->service_view_product($id);
    }
}
