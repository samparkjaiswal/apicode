<?php

namespace App\Trait;

use Illuminate\Http\Request;
use App\Service\Interface\ServiceInterface;

trait LoginTrait
{
    //Variables
    public $obj;

    //Functions
    public function __construct(ServiceInterface $obj)
    {
        $this->obj = $obj;
    }

    public function take_data(Request $req)
    {
        dd($req);
    }
}
