<?php

namespace App\Trait;
use Illuminate\Contracts\Validation\Validator;
//use Illuminate\Http\Exceptions\HttpResponseException;
use App\Exceptions\BadRequestException;

trait RequestFailedValidation
{
	protected function failedValidation(Validator $validator)
	{
		throw new BadRequestException($validator->errors()->first());
	}
}
