<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shop;
use App\Models\Order;

class OrderManagementController extends Controller
{
   // public function many($id)
    public function many(Request $request)
    {
       
          //$byshop = Shop::with('product')->where('id',$id)->get();
        //  $byshop = Shop::with('product')->paginate(10);
         // $byshop = Shop::with('product')->orderBy('id')->paginate(10);
        //  $byshop = Shop::with('product')->whereBetween('id', [1, 10])->get();

        
         
         $from = $request->from;
         $to = $request->to;

          //$byshop = Shop::with('product')->whereBetween('id', [$from, $to])->get();
          $byshop = Shop::with('product')->orderBy('id','asc')->whereBetween('id', [$from, $to])->get();
        
          //dd($byshop);

          //$byshop = Shop::with('product')->get();
         return $byshop;

    
         

         
          
    }
}
