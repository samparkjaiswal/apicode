<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Illuminate\Http\Request;

class Shop extends Model
{
    use HasFactory;
    protected $table ='shops';

    public function product()
    {
       return $this->belongsToMany(Product::class,'orders')->withPivot('id','quantity','created_at','updated_at');

     //  return $this->belongsToMany(Product::class,'orders')->withPivot('id','quantity')->wherePivotBetween('id', [1, 10]); //some issue


       //->orderByPivot('id', 'asc')->paginate(10);
       
       //->wherePivotBetween('id', [1, 10]);

       //->withPivot('quantity','created_at','updated_at')
    //    return $this->belongsToMany(Bike::class,'customerbikes','customerid','bikeid')->withPivot('city','id','created_at'); //using withPivot(coloum name) method access the middle table(pivot table) other column 
    }
}
