<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\Admin;
//use Illuminate\Support\Collection; 
use Illuminate\Auth\Middleware\Authenticate;

class MainController extends Controller
{
    public function login()
    {
        if(session()->has('Loginid'))
        {
            return redirect(route('admin.dashboard'));
        }
        else
        {
            return view('auth.login');
        }
      //  return view('auth.login');
    }

    public function register()
    {
        // if(session()->has('Loginid'))
        // {
        //     return view('auth.register');
        // }
        // else
        // {
        //     return redirect(route('auth.login'));
        // }
        return view('auth.register');
    }


    public function muserinsert(Request $request)
    {
        //return $request->input();
        
       
        //validate request
       $request->validate([

        'name' => 'required',
        'email' => 'required|email|unique:admins',
        'password' => 'required|min:5|max:12',

       ]);

       //insert data into database

       $admin = new Admin;

       $admin->name = $request->name;
       $admin->email = $request->email;
       $admin->password = Hash::make($request->password);
     //  $admin->created_by = $request->session()->get('Loginid');
       
       $save = $admin->save();

       if ($save) 
       {
        return redirect(route('auth.register'))->with('pass','Main user has been successfuly added');
       } 
       else
       {
        return back()->with('failled','Something went wrong, try again later');
       }
       
    }


    

    public function save(Request $request)
    {
        //return $request->input();
        
       
        //validate request
       $request->validate([

        'name' => 'required',
        'email' => 'required|email|unique:admins',
        'password' => 'required|min:5|max:12',

       ]);

       //insert data into database

       $admin = new Admin;

       $admin->name = $request->name;
       $admin->email = $request->email;
       $admin->password = Hash::make($request->password);
       $admin->created_by = $request->session()->get('Loginid');
       
       $save = $admin->save();

       if ($save) 
       {
        return redirect(route('admin.dashboard'))->with('Success','New user has been successfuly added');
       } 
       else
       {
        return back()->with('fail','Something went wrong, try again later');
       }
       
    }

    public function check(Request $request)
    {
        //return $request->input();

        
       

        $request->validate([

            'email' => 'required|email',
            'password' => 'required|min:5|max:12',

        ]);

        //check email in database or not
       $user = Admin::where('email','=',$request->email)->first();

        if(!$user)
        {
            return back()->with('fail','we do not recognize your email address!');
        }
        else
        {
            //check password
            if(Hash::check($request->password, $user->password))
            {
                $request->session()->put('Loginid',$user->id);
                $request->session()->put('Username',$user->name);
                $request->session()->put('Email',$user->email);
                 return redirect('admin/dashboard');
            }
            else
            {
                return back()->with('fail','Incorrect Password!');
            }
        }   

           
    }



    public function logout()
    {
        if(session()->has('Loginid'))
        {
            session()->pull('Loginid');
            return redirect('/auth/login');
        }
    }


    public function dashboard()
    {
      
   /*  $user =array();
     if(session()->has('Loginid'))
     {
        $user = Admin::where('id','=',session()->get('Loginid'))->first();   //both way we fetch data
     }
      
        return view('admin.dashboard', compact('user')); */

       /* $data = ['user'=>Admin::where('id','=', session('Loginid'))->first()];

        return view('admin.dashboard', $data); */

        if(!session()->has('Loginid'))
        {
            return view('auth.login');
           
        }
        else
        {
           // return redirect(route('auth.login'));
            $users = Admin::where('created_by', session('Loginid'))->get();
           $data = compact('users');
           return view('admin.dashboard')->with($data);
           // return view('login');
           
        }

       
    }


    public function edit($id)
    {
        if(session()->has('Loginid'))
        {
           // return view('auth.user_edit');

        $user = Admin::find($id);
        $data = compact('user');
        return view('auth.user_edit')->with($data); 
        }
        else
        {
            return view('auth.login');
        }
      
    }

    public function update(Request $request, $id)
    {
        $admin = Admin::find($id);

        $admin->name = $request->name;
        $admin->email = $request->email;
        $admin->save();

        return redirect(route('admin.dashboard'));

    }

    public function delete($id)
    {
        if(session()->has('Loginid'))
        {
            //return view('auth.changepass');
            $admin = Admin::find($id)->delete(); 
            return redirect(route('admin.dashboard')); 
        }
        else
        {
            return view('auth.login');
        }
       
      
    }

    public function changepass()
    {
       
        if(session()->has('Loginid'))
        {
            return view('auth.changepass');
        }
        else
        {
            return view('auth.login');
        }
       // return view('auth.changepass');
    }



    public function changepassword(Request $request)
    {
        $request->validate([
            
            'password' => 'required|min:5|max:12',
            'confirm_password' => 'required|same:password',
        ]);

    
       
                $user = new Admin;
                $user= Admin::where('email', session('Email'))->first();
              
                $user->password = Hash::make($request['password']);
                $user->save();
               
               
                return redirect(route('admin.dashboard'))->with('status','Password Change Successfully!');
             
       
    }

}
