<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;
use Illuminate\Support\Facades\Redis;

class MainController extends Controller
{
    public function login()
    {
        return view('auth.login');
    }

    public function register()
    {
        return view('auth.register');
    }

    public function save(Request $request)
    {
        //return $request->input();
       
        //validate request
       $request->validate([

        'name' => 'required',
        'email' => 'required|email|unique:admins',
        'password' => 'required|min:5|max:12',

       ]);

       //insert data into database

       $admin = new Admin;

       $admin->name = $request->name;
       $admin->email = $request->email;
       $admin->password = Hash::make($request->password);
       
       $save = $admin->save();

       if ($save) 
       {
        return back()->with('Success','New user has been successfuly added');
       } 
       else{
        return back()->with('fail','Something went wrong, try again later');
       }
       
    }

    public function check(Request $request)
    {
        //return $request->input();

        $request->validate([

            'email' => 'required|email',
            'password' => 'required|min:5|max:12',

        ]);

        //check email in database or not
        $user = Admin::where('email','=',$request->email)->first();

        if(!$user)
        {
            return back()->with('fail','we do not recognize your email address!');
        }
        else
        {
            //check password
            if(Hash::check($request->password, $user->password))
            {
                 $request->session()->put('Loginid',$user->id);
                 return redirect('admin/dashboard');
            }
            else
            {
                return back()->with('fail','Incorrect Password!');
            }
        }
    }



    public function logout()
    {
        if(session()->has('Loginid'))
        {
            session()->pull('Loginid');
            return redirect('/auth/login');
        }
    }


    public function dashboard()
    {
      
   /*  $user =array();
     if(session()->has('Loginid'))
     {
        $user = Admin::where('id','=',session()->get('Loginid'))->first();   //both way we fetch data
     }
      
        return view('admin.dashboard', compact('user')); */

        $data = ['user'=>Admin::where('id','=', session('Loginid'))->first()];

        return view('admin.dashboard', $data); 
    }
}
