<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Route::get('/auth/login', [MainController::class, 'login'])->name('auth.login')->middleware('AlreadyLoggedIn');

Route::get('/auth/login', [MainController::class, 'login'])->name('auth.login');

//Route::get('/auth/register', [MainController::class, 'register'])->name('auth.register')->middleware('AlreadyLoggedIn');

Route::get('/auth/register', [MainController::class, 'register'])->name('auth.register');

//Route::get('/auth/register', [MainController::class, 'register'])->name('auth.register');

Route::post('/auth/save', [MainController::class, 'save'])->name('auth.save');

Route::post('/auth/mmuserinsert', [MainController::class, 'muserinsert'])->name('auth.muserinsert');

Route::post('/auth/check', [MainController::class, 'check'])->name('auth.check');

Route::get('/auth/logout', [MainController::class, 'logout'])->name('auth.logout');

//Route::get('/admin/dashboard', [MainController::class, 'dashboard'])->name('admin.dashboard')->middleware('AuthChecking');

Route::get('/admin/dashboard', [MainController::class, 'dashboard'])->name('admin.dashboard');

Route::get('/auth/user_edit/{id}', [MainController::class, 'edit'])->name('auth.user_edit');


Route::post('/auth/user_edit/{id}', [MainController::class, 'update'])->name('auth.update');

Route::get('/auth/user_delete/{id}', [MainController::class, 'delete'])->name('auth.user_delete');

Route::get('/auth/changepass', [MainController::class, 'changepass'])->name('auth.changepass');

Route::post('/auth/changepass', [MainController::class, 'changepassword'])->name('auth.changepassword');


/*

Route::group(['middleware'=>['AuthCheck']], function()
{
    Route::get('/auth/login', [MainController::class, 'login'])->name('auth.login');
    Route::get('/auth/register', [MainController::class, 'register'])->name('auth.register');

    Route::get('/admin/dashboard', [MainController::class, 'dashboard'])->name('admin.dashboard');
}

); */


/*

//You may accomplish this using the $middlewareGroups property of your HTTP kernel.

 middleware Groups  Syntax
 
 Route::get('/', function () {
    //
})->middleware('web');
 
Route::middleware(['web'])->group(function () {
    //
});
*/

/* Syntax

Route::middleware(['first', 'second'])->group(function () {
    Route::get('/', function () {
        // Uses first & second middleware...
    });
 
    Route::get('/user/profile', function () {
        // Uses first & second middleware...
    });
});
*/