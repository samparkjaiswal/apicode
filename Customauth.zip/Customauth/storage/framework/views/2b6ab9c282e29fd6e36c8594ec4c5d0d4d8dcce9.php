<!doctype html>
<html lang="en">
  <head>
    <title>Dashboard</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <div class="container">
        <div class="row" style="margin-top:45px">
            <div class="col-md-6 offset-md-3">

                <h4>Dashboard</h4><hr>

                <table class="table table-hover">

                    <thead>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </thead>

                    <tbody>
                        <tr>
                            <td><?php echo e($user['name']); ?></td> <!-- Both way we access data -->
                            <td><?php echo e($user->email); ?></td>
                            <td><a href="<?php echo e(route('auth.logout')); ?>">Logout</a></td>
                        </tr>

                    </tbody>

                </table>

            </div>
        </div>
    </div>

  </body>
</html><?php /**PATH /opt/lampp/htdocs/Customauth/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>