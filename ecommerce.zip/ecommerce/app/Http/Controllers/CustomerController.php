<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;

class CustomerController extends Controller
{
    public function cureg()
    {
        return view('/customer/customerreg');
    }

    public function culogin()
    {
        return view('/customer/customerlogin');
    }

    public function cuhome()
    {
        return view('/customer/home');
    }

    public function dash()
    {
        return view('/admin/dash');
    }

    public function cuinsert(Request $request)
    {
        $request->validate([

            'name' => 'required',
            'email' => 'required|email|unique:customers',
            'password' => 'required|min:5|max:12',
            'mobile' => 'required|min:10|max:12',
            'address' => 'required'
    
           ]);

           $customer = new Customer;

           $customer->name = $request->name;
           $customer->email = $request->email;
           $customer->password = $request->password;
           $customer->mobile = $request->mobile;
           $customer->address = $request->address;
           $save= $customer->save();

           if($save)
           {
            return redirect(route('customer.home'));
           }
           else
           {
            return back()->with('failled','Something went wrong, try again later');
           }
    }
}
