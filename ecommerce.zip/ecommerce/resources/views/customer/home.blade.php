<!doctype html>
<html lang="en">
  <head>
    <title>Ecommerce Website</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>

      .card-img-top{
        width:100%;
        height:200px;
        object-fit: contain;
      }

    </style>

  </head>
  <body>
      
   <div class="container-fluid p-0">
     
    <nav class="navbar navbar-expand-lg  bg-info">
      <div class="container-fluid">
        <a class="navbar-brand" style="color:white;font-weight:bold" href="#">Logo</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <ul class="navbar-nav me-auto mb-2 mb-lg-0">

            <li class="nav-item">
              <a class="nav-link active" aria-current="page"  href="#"><span class="fa fa-home" style="color:white;font-weight:bold"> Home</span></a>
            </li>

            {{-- <li class="nav-item">
              <a class="nav-link"  href="#"><span class="fa fa-product-hunt" style="color:white;font-weight:bold"> Products</span></a>
            </li> --}}
            <!-- Modal -->

            


            <div class="modal" id="RegisterModal">
              <div class="modal-dialog">
                  <div class="modal-content">
          
                      <div class="modal-header">
                          <h5 class="modal-title">Customer Registration</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                      </div>

                      <div class="modal-body">

                        <form id="addform">

                       
                          @if (Session::get('failled'))
                          <div class="alert alert-danger">
                              {{ Session::get('failled') }}
                          </div>
                          @endif
                          
            
                            @csrf
                         
                        <div class="form-group">
                          <label for="name">Name</label>
                          <input type="text" class="form-control" name="name"  value="{{ old('name') }}" id="name" aria-describedby="helpId" placeholder="Enter name">
                          <span class="text-danger">@error('name'){{ $message }} @enderror</span>
                        </div>
            
            
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" name="email" value="{{ old('email') }}" id="email" aria-describedby="helpId" placeholder="Enter email id">
                            <span class="text-danger">@error('email'){{ $message }} @enderror</span>
                          </div>
            
                          <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" value="" id="password" aria-describedby="helpId" placeholder="Create password">
                            <span class="text-danger">@error('password'){{ $message }} @enderror</span>
                          </div>
            
                          <div class="form-group">
                            <label for="mobile">Mobile</label>
                            <input type="tel" class="form-control" name="mobile" value="{{ old('mobile') }}" id="mobile" aria-describedby="helpId" placeholder="Enter mobile">
                            <span class="text-danger">@error('mobile'){{ $message }} @enderror</span>
                          </div>
            
                          <div class="form-group">
                            <label for="address">Address</label>
                            <textarea name="address" id="address" class="form-control" value="{{ old('address') }}" placeholder="Enter full address"></textarea>
                            <span class="text-danger">@error('address'){{ $message }} @enderror</span>
                          </div>

                          <div class="modal-footer">

                            <button type="button" class="btn-close btn btn-secondary" data-bs-dismiss="modal">Close</button>

                            <button type="submit" class="btn btn-success" name="submit" id="frmSubmit">Sign Up</button>
                            

                          </div>
            
                         
                          {{-- <a href="{{ route('customer.login') }}">I have already an account, sign in</a> --}}

                        </form>
                       
                      </div>

                    
          

                  </div>

              </div>
            </div>
            <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
            <script>

              $(document).ready(function(){
                $('#addform').on("click",function(e){
                  e.preventDefault();//e means event prevenDefault function it's use for don't do any action on click any button or url
                  //console.log("hello");
                  // var data = {                  //make a object of all form data
                  //   'name': $('#name').val(),
                  //   'email': $('#email').val(),
                  //   'password': $('#password').val(),
                  //   'moblile': $('#mobile').val(),
                  //   'address': $('#address').val(),
                  }
                 // console.log(data);

                 $.ajax({
                  type: "POST",
                  url: "/customer/reg",
                  data: $('#addform').serialize(),  


                  dataType: "dataType",
                  success: function (response) {
                    
                  }
                 });

                });
              
                    // The serialize() method creates a URL encoded text string by serializing form values.

                    // You can select one or more form elements (like input and/or text area), or the form element itself.

                    // The serialized values can be used in the URL query string when making an AJAX request.



              </script>



              
            
                <li class="nav-item">
                  <a class="nav-link"   data-bs-toggle="modal" data-bs-target="#RegisterModal"><span class="fa fa-user-plus" style="color:white;font-weight:bold"> Register</span></a>
                </li>
    
             


            

            <li class="nav-item">
              <a class="nav-link"  href="#"><span class="fa fa-shopping-cart" style="color:white;font-weight:bold"> Cart</span></a>
            </li>

            {{-- <li class="nav-item">
              <a class="nav-link" style="color:white;font-weight:bold" href="#"> Total Price:100/-</a>
            </li> --}}
            
            
          </ul>
          <form class="d-flex" role="search" style="margin-left:600px;">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-success" type="submit">Search</button>
          </form>
        </div>
      </div>
    </nav>

    <!--Second Chiled--->

    <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
     <ul class="navbar-nav me-auto">

      <li class="nav-item">
        <a class="nav-link" href="#"><span class="fa fa-user" style="color:white;font-weight:bold"> Welcome Guest</span></a>

        <li class="nav-item">
          <a class="nav-link" href="{{ route('customer.login') }}"><span class="fa fa-sign-in" style="color:white;font-weight:bold"> Login</span></a>
      </li>
     </ul>
    </nav>

    <!--third child-->

    <div class="" style="background:#dae452">
      <h3 class="text-center" style="font-weight:bold">Our Store</h3>
      <p class="text-center">Do Something New For You</p>
  
    </div>

    <!--Fourht child-->

    <div class="row">
      <div class="col-md-12">
        <!--product-->
        <div class="row">
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="{{ asset('img/jam.jpg') }}" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="{{ asset('img/camera.jpg') }}" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="{{ asset('img/tata.jpeg') }}" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="{{ asset('img/tata.jpeg') }}" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="{{ asset('img/tata.jpeg') }}" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="{{ asset('img/tata.jpeg') }}" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
        </div>
      </div>


       <!--sidenav-->

      {{-- <div class="col-md-2 bg-secondary p-0">
       
        <!-- Brands Display -->
        <ul class="navbar-nav me-auto text-center">

          <li class="nav-item bg-info">
            <a href="#" class="nav-link text-light"><h4>Delivery Brands</h4></a>
          </li>


          <li class="nav-item">
            <a href="#" class="nav-link text-light">Brand1</a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link text-light">Brand2</a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link text-light">Brand3</a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link text-light">Brand4</a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link text-light">Brand5</a>
          </li>

        </ul>
       
        <!-- Categary Dispaly -->
        <ul class="navbar-nav me-auto text-center">

          <li class="nav-item bg-info">
            <a href="#" class="nav-link text-light"><h4>Categories</h4></a>
          </li>


          <li class="nav-item">
            <a href="#" class="nav-link text-light">Categories1</a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link text-light">Categories2</a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link text-light">Categories3</a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link text-light">Categories4</a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link text-light">Categories5</a>
          </li>

        </ul>

      </div> --}}

    </div>


    <!--Footer-->

    <div class="bg-info p-3 text-center">
      <p>@Copyright Designed By Ashriya Infotech</p>
    </div>


   </div>
   <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>

   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
   
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>