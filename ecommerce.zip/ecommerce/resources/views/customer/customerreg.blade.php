<!doctype html>
<html lang="en">
  <head>
    <title>Registration</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>


    <div class="container">

        <div class="row">
            
            <div class="col-md-4 offset-md-4">
            <form action="{{ route('customer.insert') }}" method="post" autocomplete="off">

              @if (Session::get('failled'))
              <div class="alert alert-danger">
                  {{ Session::get('failled') }}
              </div>
              @endif

                @csrf
                <h2 class="text-center danger">Registration</h2>
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name" value="{{ old('name') }}" id="" aria-describedby="helpId" placeholder="Enter name">
              <span class="text-danger">@error('name'){{ $message }} @enderror</span>
            </div>


            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" value="{{ old('email') }}" id="" aria-describedby="helpId" placeholder="Enter email id">
                <span class="text-danger">@error('email'){{ $message }} @enderror</span>
              </div>

              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" value="" id="" aria-describedby="helpId" placeholder="Create password">
                <span class="text-danger">@error('password'){{ $message }} @enderror</span>
              </div>

              <div class="form-group">
                <label for="mobile">Mobile</label>
                <input type="tel" class="form-control" name="mobile" value="{{ old('mobile') }}" id="" aria-describedby="helpId" placeholder="Enter mobile">
                <span class="text-danger">@error('mobile'){{ $message }} @enderror</span>
              </div>

              <div class="form-group">
                <label for="address">Address</label>
                <textarea name="address" id="" class="form-control" value="{{ old('address') }}" placeholder="Enter full address"></textarea>
                <span class="text-danger">@error('address'){{ $message }} @enderror</span>
              </div>

              <button type="submit" class="btn btn-success">Sign Up</button><br>
              {{-- <a href="{{ route('customer.login') }}">I have already an account, sign in</a> --}}
            </form>

        </div>
        </div>
    </div>
      
    
   
  </body>
</html>