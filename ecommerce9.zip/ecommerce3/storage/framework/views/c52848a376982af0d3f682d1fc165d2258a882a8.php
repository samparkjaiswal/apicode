<!doctype html>
<html lang="en">
  <head>
    <title>Admin Dashboard</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
         .row li{
        display:inline;
    }
    </style>
  </head>
  <body>


    <div class="container-fluid">

        <div class="row" style="min-height:80px;background:lightgreen">
            <div class="col-md-12">
             <h1 style="text-align:center;font-weight:900">Admin Panel</h1>
            </div>
        
        </div>

        <div class="row">
            <div class="col-md-12" style="min-height:50px;background:cyan">
                
             
                <ul style="list-style-type:none;margin-top:10px;">
                    <li style=""><a href="" style="color:black;text-decoration:none;font-size:20px;font-weight:bold">Hello, <span class="" style="color:red"> <?php if(session()->has('Loginid')): ?>
                      <?php echo e(session('Name')); ?>

                    <?php endif; ?></span></a></li>

                    <li style="padding-left:20px"><a href="" style="color:black;text-decoration:none;font-size:20px;font-weight:bold"><span class="fa fa-home" style="color:red"></span> Home</a></li>
                    <li style="margin-left:25px"><a href="/admin/addproduct" style="color:black;text-decoration:none;font-size:20px;font-weight:bold"><span class="fa fa-product-hunt" style="color:red"></span>  Add Product</a></li>
                    <li style="margin-left:25px"><a href="<?php echo e(route('admin.order')); ?>" style="color:black;text-decoration:none;font-size:20px;font-weight:bold"><span class="fa fa-database" style="color:red"></span> Order Management</a></li>
                    <li style="margin-left:25px"><a href="" style="color:black;text-decoration:none;font-size:20px;font-weight:bold"><span class="fa fa-truck" style="color:red"></span> Delivery Management</a></li>
                    <li style="float:right;margin-right:30px"><a href="<?php echo e(route('logout')); ?>" style="color:black;text-decoration:none;font-size:20px;font-weight:bold"><span class="fa fa-sign-out" style="color:red"></span> Logout</a></li>
                    
                </ul>

            </div>
        </div>
       
           
    </div>

    <div id="app">
      <main class="py-4">
         <?php echo $__env->yieldContent('content'); ?>   
          
      </main>
    </div>

      

    
  </body>
</html>

<?php /**PATH /opt/lampp/htdocs/ecommerce3/resources/views/admin/dash.blade.php ENDPATH**/ ?>