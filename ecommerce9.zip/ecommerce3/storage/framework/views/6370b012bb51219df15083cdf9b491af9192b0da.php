<!doctype html>
<html lang="en">
  <head>
    <title>Ecommerce Website</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>

      .card-img-top{
        width:100%;
        height:200px;
        object-fit: contain;
      }

    </style>

  </head>

<body>
    <div class="container-fluid p-0">

        <nav class="navbar navbar-expand-lg  bg-info">
            <div class="container-fluid">
              <a class="navbar-brand" style="color:white;font-weight:bold" href="#">Logo</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
      
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
      
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page"  href="<?php echo e(route('user.carddisplay')); ?>"><span class="fa fa-home" style="color:white;font-weight:bold"> Home</span></a>
                  </li>
      
               
      


                  
                  
                  
                </ul>
                
              </div>
            </div>
          </nav>



          <!--- Second  -->



          <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
            <ul class="navbar-nav me-auto">
             
             
         
             <li class="nav-item">
               <a class="nav-link" href="#"><span class="fa fa-user" style="color:white;font-weight:bold"> Welcome 
       
                 <?php if(session()->has('Loginid')): ?>
                 <?php echo e(session('Name')); ?> <?php endif; ?>
       
               </span></a>
                
             </li>
              
       
               
       
             
             
             <li class="nav-item">
               <a class="nav-link active" aria-current="page"  href="<?php echo e(route('logout')); ?>" style="margin-left:1200px"><span class="fa fa-sign-out" style="color:white;font-weight:bold"> Logout</span></a>
             </li>
             
            </ul>
        </nav>

        <?php if(session()->get('ordersuccess')): ?>
        
      
        <div class="alert alert-success">
          <button type="button" class="close" data-bs-dismiss="alert">x</button>
          
          <?php echo e(session('ordersuccess')); ?></div>
  
        <?php endif; ?>

      
        <center>
            
        <table class="table-bordered table-striped table-hover" style="margin-top: 50px;border:2px solid black">
            <thead class="table-dark text-center">
                <tr>
                <th>Product Name</th>
                <th>Product Price</th>
                <th>Product Quantity</th>
                <th>Action</th>
            </tr>
            </thead>

            <tbody class="text-center">

                <?php
                    $total = 0;
                ?>
               
                  <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                 
               
                <tr>

                <td><?php echo e($cart->productname); ?></td>
                <td><?php echo e($cart->productprice); ?></td>
                <td><?php echo e($cart->productquantity); ?></td>
                <td>
                    <a href="<?php echo e(route('user.delcart',['cartid'=>$cart->cartid])); ?>" style="color:red">Remove</a>
                </td>

                </tr>
                <?php
                
                $total += $cart->productprice*$cart->productquantity;

            ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </tbody>
        
        </table>
      


        <div class="row" style="margin-left:1200px;margin-top:50px">
            <div class="col-md-6">
            <div class="shadow-sm bg-warning">
            <h4 style="font-weight:900">Total Price: <?php echo e($total); ?>.00<span></span></h4>
            
             </div>
        </div>
        
        
            </div>

          

            <div class="row" style="margin-left:1200px;">
                <div class="col-md-6">
                
                

             <a  class="btn btn-success" data-url=""    id="fetchemail" data-bs-toggle="modal" data-bs-target="#DeliveryModal">Place Order</a>

           
   

            </div>  
            </div>

            
            
        </center>
        <div class="modal" id="DeliveryModal">

            <div class="modal-dialog">
                <div class="modal-content">
      
                     <div class="modal-header bg-warning">
                        <h5 class="modal-title">Order Delivery Page</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
    
    
                    <div class="modal-body">


                   
                     
                        
    
                        <form id="deliverproduct" action="<?php echo e(route('cart.delivery',['orderid'=>$cart->email])); ?>" autocomplete="off" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
    
                            <div class="form-group">
                              <label for="">Name</label>
                              <input type="text" name="name" id="name" class="form-control" placeholder="Enter  name" aria-describedby="helpId">  
                            </div>

                            <div class="form-group">
                                <label for="">Phone</label>
                                <input type="tel" name="mobile" id="mobile" class="form-control" placeholder="Enter phone number" aria-describedby="helpId">  
                              </div>

                              <div class="form-group">
                                <label for="">City</label>
                                <input type="text" name="city" id="city" class="form-control" placeholder="Enter city" aria-describedby="helpId">  
                              </div>


                              <div class="form-group">
                                <label for="">Pincode</label>
                               <input type="text" name="pincode" id="pincode" class="form-control" placeholder="Enter area pincode" aria-describedby="helpId">  
                              </div>


                              <div class="form-group">
                                <label for="">Address</label>
                               <textarea name="address" id="address" placeholder="Enter full address" class="form-control" ></textarea>  
                              </div>
    
                                
                                <div class="modal-footer">
    
                                    <button type="button" class="btn-close btn btn-secondary" data-bs-dismiss="modal">Close</button>
              
                                    <button type="submit" class="btn btn-success" name="submit" id="add">Submit</button>
                                    
              
                                  </div>
                    
                        </form>
    
    
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>




        // $(document).ready(function(){
    
        //   //fetch id

        // //  $('body').on('click','#fetchemail', function(){
         
        // //   var custemail =$(this).data('url');
        // //   $.get(custemail, function(data){
        // //     $('#deliverproduct').modal('show');
        // //   })
        // //  // alert(custemail);
        // //  });



        //  //insert data

        //     $('#deliverproduct').submit(function(e){
    
        //         e.preventDefault();

               

                
        //         let formdata = new FormData($('#deliverproduct')[0]);
    
        //         $.ajax({
        //             type: "POST",
        //             url: "/cart/delivery",
        //             data: formdata,
        //             contentType:false,
        //             processData:false,
        //             success: function (response) {
        //             //console.log(response);
        //             $('#DeliveryModal').modal('hide');
        //             alert('Record Submitted');
                    
        //             },
        //             error:function(error){
        //             //console.log(error);
        //             $('#PDeliveryModal').modal('hide');
        //             alert('Record Not Submitted');
        //       }
        //         });
    
        //     });
        // });
    </script>

    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>


</body>

</html><?php /**PATH /opt/lampp/htdocs/ecommerce3/resources/views//customer/showcart.blade.php ENDPATH**/ ?>