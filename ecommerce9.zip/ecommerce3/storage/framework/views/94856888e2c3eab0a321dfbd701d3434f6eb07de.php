<?php $__env->startSection('content'); ?>







<div class="container">
  

    <div class="row" style="margin-top:50px">
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-warning text-white">Order Management</div>
                <div class="card-body">
                    
                    
                    <table class="table table-responsive table-bordered table-striped">

                        <thead class="table-dark"> 
                            <tr class="text-center">
                                <th>Order_Id</th>
                                <th>Customer_Name</th>
                                <th>Phone</th>
                                <th>City</th>
                                <th>Pincode</th>
                                <th>Address</th>
                                <th>Product_Name</th>
                                <th>Total_Price</th>
                                <th>Product_Quantity</th>
                                <th>Order_Email</th>
                               
                            </tr>
                        </thead>


                        <tbody>
                         
                             <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                
                          
                               
                           
                             
                            <tr class="text-center">
                                <td><?php echo e($data->orderid); ?></td>
                                <td><?php echo e($data->customername); ?></td>
                                <td><?php echo e($data->mobile); ?></td>
                                <td><?php echo e($data->city); ?></td>
                                <td><?php echo e($data->pincode); ?></td>
                                <td><?php echo e($data->address); ?></td>
                                <td><?php echo e($data->productname); ?></td>
                                <td><?php echo e($data->productprice); ?></td>
                                <td><?php echo e($data->productquantity); ?></td>
                                <td><?php echo e($data->orderemail); ?></td>
                            </tr> 
                         
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                
              
                </div>
          

        </div>
    </div>



</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecommerce3/resources/views//admin/ordermanage.blade.php ENDPATH**/ ?>