@extends('admin.dash')

@section('content')







<div class="container">
  

    <div class="row" style="margin-top:50px">
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-warning text-white">Order Management</div>
                <div class="card-body">
                    
                    
                    <table class="table table-responsive table-bordered table-striped">

                        <thead class="table-dark"> 
                            <tr class="text-center">
                                <th>Order_Id</th>
                                <th>Customer_Name</th>
                                <th>Phone</th>
                                <th>City</th>
                                <th>Pincode</th>
                                <th>Address</th>
                                <th>Product_Name</th>
                                <th>Total_Price</th>
                                <th>Product_Quantity</th>
                                <th>Order_Email</th>
                               
                            </tr>
                        </thead>


                        <tbody>
                         
                             @foreach ($datas as $data) 
                                
                          
                               
                           
                             
                            <tr class="text-center">
                                <td>{{ $data->orderid }}</td>
                                <td>{{ $data->customername }}</td>
                                <td>{{ $data->mobile }}</td>
                                <td>{{ $data->city }}</td>
                                <td>{{ $data->pincode }}</td>
                                <td>{{ $data->address }}</td>
                                <td>{{ $data->productname }}</td>
                                <td>{{ $data->productprice }}</td>
                                <td>{{ $data->productquantity }}</td>
                                <td>{{ $data->orderemail }}</td>
                            </tr> 
                         
                            @endforeach
                        </tbody>
                    </table>
                
              
                </div>
          

        </div>
    </div>



</div>






@endsection
