<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;

class StudentController extends Controller
{
    public function stuinsert(Request $request)
    {
        $student = new Student;

        $student->name = $request->name;
        $student->email = $request->email;
        $student->password = $request->password;

        $student->save();
        return response()->json($student);
    }

    public function show()
    {
       $student =Student::all();
        return response()->json($student);
    }

    public function update(Request $request, $stdid)
    {
       
    $student = Student::where('stdid',$stdid);
    $student->update($request->all());
    return response()->json($student);
    }

    public function delete(Request $request, $stdid)
    {
        $student = Student::where('stdid',$stdid)->delete();

        return response()->json($student);
    
    }
}
