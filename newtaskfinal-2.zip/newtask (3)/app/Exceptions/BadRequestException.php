<?php

namespace App\Exceptions;

use Exception;
use Throwable;

class BadRequestException extends Exception implements Throwable
{
    
}
