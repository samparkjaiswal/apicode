<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use App\Service\Interface\IUserService;

use App\Service\UserService;

use App\Repository\Interface\IUserRepository;
use App\Repository\UserRepository;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(IUserService::class, UserService::class);
        $this->app->bind(IUserRepository::class, UserRepository::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
