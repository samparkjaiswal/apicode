<?php
namespace App\Traits;

use Illuminate\Http\Request;
use App\Helper\UserHelper;
use App\Service\Interface\IUserService;



//use Illuminate\Support\Facades\Request;


use App\Http\Requests\V1\RegisterUserRequest;


trait UserAction
{
    public $userservice;

   // private $userHelper;  //Validation Work Without call User helper class and without making object
   //public function __construct(IUserService $userservice,UserHelper $userHelper)

    public function __construct(IUserService $userservice)
    {
        $this->userservice = $userservice;
        
     //   $this->userHelper = $userHelper;

    }

    public function insert(RegisterUserRequest $request)
    {
       
        return $this->userservice->insert($request);
    }


    public function display()
    {
       
        return $this->userservice->showdis();
    }

    public function delete($id)
    {
        return $this->userservice->remove($id);
    }

    public function update(RegisterUserRequest $request,$id)
 
    {
        
       
        return $this->userservice->edit($request,$id);
    }

   
}

