<?php
namespace App\Service;

use App\Service\Interface\IUserService;
use App\Repository\Interface\IUserRepository;

use App\Helper\UserHelper;
use App\Http\Requests\V1\RegisterUserRequest;
use App\Http\Requests\V1\UpdateUserRequest;


class UserService implements IUserService
{
    public $userrepository;
    private $userHelper;

    public function __construct(IUserRepository $userrepository,UserHelper $userHelper)

  //  public function __construct(IUserRepository $userrepository)
    {
        $this->userrepository = $userrepository;

        $this->userHelper = $userHelper;
    }

    public function insert(RegisterUserRequest $request)
    {
        $data = $this->userHelper->User($request);

       $register = $this->userrepository->createUser($data);

       return $register;

    //   return response()->json(['UserService'=> $request], 200);


    }


    public function showdis()
    {
        return $this->userrepository->showdata();
    }

    public function remove($id)
    {
        return $this->userrepository->cutdata($id);
    }

  
    public function edit(RegisterUserRequest $request,$id)
    {
      
       $rec = $this->userHelper->User($request);
        return $this->userrepository->updatedata($rec,$id);
    }
   
}

