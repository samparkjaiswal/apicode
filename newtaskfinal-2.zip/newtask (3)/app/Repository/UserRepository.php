<?php
namespace App\Repository;

use App\Repository\GenericRepository;
use App\Repository\Interface\IUserRepository;

use App\Models\Student;


class UserRepository extends GenericRepository implements IUserRepository
{
    public function model()
    {
        return Student::class;
    }


    public function createUser(array $data)
    {
        $user = $this->model->create($data);
        return $user;
    }

    public function showdata()
    {
      
        $show = $this->model->all('*');
        //dd($show);
       return $show;
    }

 
   public function cutdata($id)
   {
     $student = $this->model->destroy($id);
     return $student;
   }

   public function updatedata(array $rec,$id)
  
   {
    
    $find = $this->model->find($id,'*');
   
     return $find->update($rec);
    
   }


}