<?php

namespace App\Repository\Interface;


use App\Repository\Interface\IGenericRepository;

interface IUserRepository extends IGenericRepository
{
  public function createUser(array $data);

  public function showdata();

  public function cutdata($id);

  public function updatedata(array $rec,$id);

 
  
}