<?php
namespace App\Helper;

use Illuminate\Http\Request;


class UserHelper
{
    public function User($request)
    {
       return  [
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password
        ];
       
    }
}