<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\SingleActionController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\RegistrationController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */





Route::get('/basic', [PageController::class, 'home']);//1st way to call basic controller
//Route::get('/','App\Http\Controllers\PageController@home');//second way  to call basic controller

Route::get('/single', SingleActionController::class);//way to call single action controller

Route::resource('/resource', PhotoController::class);//way to call resource controller

Route::get('/register', [RegistrationController::class, 'index']);

Route::post('/register', [RegistrationController::class, 'register']);





//if we don't call the conroller then use below code



Route::get('/', function () {
    return view('welcome');
});
/*
Route::get('/chk', function () {
    return view('main');
});

Route::get('/post', function () {
    return view('app');
});
*/





//SESSION CODE



//Store  Session Value and Retrive and destroy Via 'Request Instance'

/*
//set session

Route::get('/sessionset', function(Request $request) {

    $request->session()->put('name', 'Rahul'); //1st way to set up session
    $request->session()->flash('status', 'Success'); //For Displaying Flash Massage who display few on only one request
}); 

//for retrive data 

Route::get('/sessionget', function(Request $request){

        //  $value = $request->session()->all(); //if we want 
        // echo "<pre>";
        // print_r($value);
        //   echo "</pre>"; 

    $value = $request->session()->get('name');
     $val = $request->session()->get('status');
 
    print_r($value);
    echo "<br>";
    print_r($val);
 
});

//destroy session

Route::get('/destroy', function(Request $request){

    $request->session()->forget('name');
    // $request->session()->flush(); 
});
*/



//Store Session Value and Retrive and destroy Via 'Global Session Helper'


//set session 
Route::get('/setsession', function(){
    
    session(['user'=>'rahul']);
    session()->flash('status', 'Success');  //For Displaying Flash Massage who display few on only one request
    
});

//get session
Route::get('/getsession', function(){


    // $value = session()->all();
    // echo "<pre>";
    // print_r($value);
    // echo "</pre>";

    $value = session('user');
    $val = session('status');
    print_r($value);
    echo "<br>";
    print_r($val);
});

//destroy session
Route::get('/destroy', function(){

    session()->forget('user');
    //session()->flush();
});







// ACCESS Session Value On Form this code belong to other page where we want show session data

// { {{ session('user') }} --}}
//  {{-- @if (session()->has('user'))
//    {{ session('user') }}
//  @else
//    guest 
//  @endif 