<!doctype html>
<html lang="en">
  <head>
    <title>Registration</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
        <h1 class="text-center" style="">Registration Form</h1>

        <form action="{{url('/')}}/register" method="post" autocomplete="off">
          @csrf

          <!--ACCESS Session Value On Form -->

           {{-- {{ session('user') }} --}}
            {{-- @if (session()->has('user'))
              {{ session('user') }}
            @else
              guest 
            @endif --}}

        <div class="form-group">
          <label for="name">Name:</label>
          <input type="text" name="name" id="" class="form-control" placeholder="" value="{{  old('name') }}" aria-describedby="helpId">
          <span class="text-danger">
            @error('name')
              {{$message}}
            @enderror
          </span>
        
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" name="email" id="" class="form-control" placeholder="" aria-describedby="helpId">
            <span class="text-danger">
              @error('email')
                {{$message}}
              @enderror
            </span>
          </div>

          <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" name="password" id="" class="form-control" placeholder="" aria-describedby="helpId">
            <span class="text-danger">
              @error('password')
                {{$message}}
              @enderror
            </span>
          </div>

          <div class="form-group">
            <label for="cpass">Confirm Password:</label>
            <input type="password" name="confirm_password" id="" class="form-control" placeholder="" aria-describedby="helpId">
            <span class="text-danger">
              @error('confirm_password')
                {{$message}}
              @enderror
            </span>
          </div>

          <button type="submit" class="btn btn-success">Submit</button>

        </form>
    </div>  
    
  </body>
</html>