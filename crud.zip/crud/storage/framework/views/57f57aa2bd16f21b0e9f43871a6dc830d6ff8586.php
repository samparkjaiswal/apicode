<!doctype html>
<html lang="en">
  <head>
    <title>Registration Form</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>

    <div class="container">

        <div class="text-center" style="font-size:35px">Update Record</div>

        <!--1st Way Updation By URL -->
<?php //dd($customer) ?>

<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <form action="<?php echo e(url('/')); ?>/register/update/<?php echo e($valu['id']); ?>" method="post" autocomplete="off"> 

    <!-- 2nd Way Updatoin By Route -->

  <!--  <form action="" method="post" autocomplete="off"> -->

            <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="">Name:</label>
          <input type="text" name="name" id="" class="form-control" placeholder="" value="<?php echo e($customer->name); ?>" aria-describedby="helpId">
          <span class="text-danger">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

            <?php echo e($message); ?>


            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
          
        </div>

        <div class="form-group">
            <label for="">Email:</label>
            <input type="text" name="email" id="" class="form-control" placeholder="" value="<?php echo e($customer->email); ?>" aria-describedby="helpId">
            <span class="text-danger">
                
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        
                    <?php echo e($message); ?>

        
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  
            </span>
            
          </div>

         

          <div class="form-group">
            <label for="">Contact:</label>
            <input type="tel" name="mobile" id="" class="form-control" value="<?php echo e($customer->mobile); ?>" placeholder="" aria-describedby="helpId">
            <span class="text-danger">
                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        
                <?php echo e($message); ?>

    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
            
          </div>

          <div class="form-group">
            <label for="">Address:</label>
            <textarea type="text" name="address" id="" cols="" rows="" class="form-control" placeholder="" aria-describedby=""><?php echo e($customer->address); ?></textarea>
            <span class="text-danger">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        
                <?php echo e($message); ?>

    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
            
          </div>

          <button type="submit" class="btn btn-primary">Update</button>

        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
      
  
  </body>
</html><?php /**PATH /opt/lampp/htdocs/crud/resources/views/customer_edit.blade.php ENDPATH**/ ?>