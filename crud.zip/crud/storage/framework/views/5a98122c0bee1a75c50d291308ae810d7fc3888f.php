<!doctype html>
<html lang="en">
  <head>
    <title>Display Data</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
      
    <div class="container">
        <table class="table table-striped table-bordered table-hover">
            <pre>
                
            </pre>
            <thead class="thead-dark">
                <tr class="text-center">
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th colspan="2">Operation</th>
                </tr>
            </thead >
            <tbody>

               <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                
                <tr class="text-center">
                    <td><?php echo e($customer->name); ?></td>
                    <td><?php echo e($customer->email); ?></td>
                    <td><?php echo e($customer->mobile); ?></td>
                    <td><?php echo e($customer->address); ?></td>

                     <!-- 1st Way  Updation By URL-->

                  <td><a href="<?php echo e(url('/register/edit/')); ?>/<?php echo e($customer->id); ?>"><span class="fa fa-edit text-primary" style="font-size:20px"></span></a></td> 


                <!-- 2nd Way  Updation By Route-->

           <!--     <td><a href=""><span class="fa fa-edit text-primary" style="font-size:20px"></span></a></td> -->

                      <!-- 1st Way  Deletion By URL-->

                   <td><a href="<?php echo e(url('/register/delete/')); ?>/<?php echo e($customer->id); ?>"><span class="fa fa-trash text-danger" style="font-size:20px"></span></a></td> 

                  <!-- 2nd Way  Deletion By ROUTE SEE THE Youtube video wscube-->

              <!--    <td><a href=""><span class="fa fa-trash text-danger" style="font-size:20px"></span></a></td>-->



                  

            
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        
        </table>
    </div>

  </body>
</html><?php /**PATH /opt/lampp/htdocs/crud/resources/views/customer_display.blade.php ENDPATH**/ ?>