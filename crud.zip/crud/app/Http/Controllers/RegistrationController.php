<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;

class RegistrationController extends Controller
{
    public function index()
    {
        return view('registration');
    }

    public function register(Request $request)
    {
        $request->validate(
            [
                'name' => 'required',
                'email' => 'required|email',
                'password' => 'required',
                'mobile' => 'required|',
                'address' => 'required',
            ]
            );
           // echo "<pre>";
           // print_r($request->all());
            //insert query
       /*     $customer = new Customer;  //this is  Eloquent ORM method data Fetch
            $customer->name = $request['name'];
            $customer->email = $request['email'];
            $customer->password = md5($request['password']);
            $customer->mobile = $request['mobile'];
            $customer->address = $request['address'];
            $customer->save();*/

            DB::insert('insert into customers (name,email,password,mobile,address) values (?, ?, ?, ?, ?)', [$request['name'], $request['email'], md5($request['password']), $request['mobile'], $request['address']]); //this is 2nd way for data fetch

            return redirect('register');
    }

    public function display()
    {
       
       /*$customers = Customer::all(); //this is Eloquent ORM method data fetch

      // echo "<pre>";
     //  print_r($customers);
     //  echo "</pre>";
       
        $data =compact('customers');*/ 

       $customers = DB::select('select * from customers');  //this is 2nd way for data fetch
        $data = compact("customers");
        
        return view('customer_display')->with($data);
    }


    public function delete($id)
    {
       // echo $id;
      /* $customer = Customer::find($id)->delete();  //this is Eloquent ORM method data delete
       return redirect('/register/display'); */
       //echo "<pre>";
       //print_($customer);

       $customer = DB::delete('delete from customers where id =?', [$id]); //2nd way to delete data

       return redirect('/register/display');
       
    }

    public function edit($id)
    {
        $customer = Customer::find($id);
        $data = compact('customer');
        return view('customer_edit')->with($data); 

    /*    $customer = DB::select('select * from customers where id =?', [$id]);
        $data = compact('customer');
        return view('customer_edit')->with($data); */   //error
    }

    public function update(Request $request, $id)
    {
        $customer = Customer::find($id);

        $customer->name = $request['name'];
        $customer->email = $request['email'];
        $customer->mobile = $request['mobile'];
        $customer->address = $request['address'];
        $customer->save();

        return redirect('/register/display'); 

    }
}

