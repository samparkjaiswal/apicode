<!doctype html>
<html lang="en">
  <head>
    <title>Registration Form</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>

    <div class="container">

        <div class="text-center" style="font-size:35px">Update Record</div>

        <!--1st Way Updation By URL -->
<?php //dd($customer) ?>


       <form action="{{ url('/') }}/register/update/{{ $customer->id}}" method="post" autocomplete="off"> 

    <!-- 2nd Way Updatoin By Route -->

  <!--  <form action="{{-- route('register.update',['id'=>$customer->id]) --}}" method="post" autocomplete="off"> -->

            @csrf
        <div class="form-group">
          <label for="">Name:</label>
          <input type="text" name="name" id="" class="form-control" placeholder="" value="{{ $customer->name }}" aria-describedby="helpId">
          <span class="text-danger">
            @error('name')

            {{ $message }}

            @enderror
          </span>
          
        </div>

        <div class="form-group">
            <label for="">Email:</label>
            <input type="text" name="email" id="" class="form-control" placeholder="" value="{{ $customer->email }}" aria-describedby="helpId">
            <span class="text-danger">
                
                    @error('email')
        
                    {{ $message }}
        
                    @enderror
                  
            </span>
            
          </div>

         

          <div class="form-group">
            <label for="">Contact:</label>
            <input type="tel" name="mobile" id="" class="form-control" value="{{ $customer->mobile }}" placeholder="" aria-describedby="helpId">
            <span class="text-danger">
                @error('mobile')
        
                {{ $message }}
    
                @enderror
            </span>
            
          </div>

          <div class="form-group">
            <label for="">Address:</label>
            <textarea type="text" name="address" id="" cols="" rows="" class="form-control" placeholder="" aria-describedby="">{{ $customer->address }}</textarea>
            <span class="text-danger">
                @error('address')
        
                {{ $message }}
    
                @enderror
            </span>
            
          </div>

          <button type="submit" class="btn btn-primary">Update</button>

        </form>
    </div>
      
  
  </body>
</html>