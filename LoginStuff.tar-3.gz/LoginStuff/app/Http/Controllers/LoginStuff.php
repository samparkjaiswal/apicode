<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LoginStuff extends Controller
{
    public function show_login_form()
    {
        return view('loginform');
    }

    public function show_registeration_form()
    {
        return view('registerform');
    }

    public function welcome_page()
    {
        if(session()->has('loggeduser')){
            $data =DB::table('aliencommunity')->where('id', session('loggeduser'))->first();
            return view('welcome', ['data' => $data]);
        }
        else {
            return redirect(route('loginformshow'));
        }
    }
    
    public function logout()
    {
        if(session()->has('loggeduser')){
            session()->pull('loggeduser');
            return redirect(route('loginformshow'));
        }
    }

}
