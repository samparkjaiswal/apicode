<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Silkscreen&display=swap" rel="stylesheet">
    <title>Registeration Form</title>
    <style>
        span {
            color: red;
        }
        body {
            margin: 0;
            padding: 0;
            font-family: 'Silkscreen', cursive;
        }
        h1
        {
            position: absolute;
            top: 18%; 
            left: 45%;
        }
        h2 {
            font-size: 15px;
        }
    </style>
</head>
<body>
    <h1>Sign Up</h1>
    <form action="{{route('storedata')}}" method="post" class="form-control p-5" style="margin: 220px auto; margin-bottom: 0; width: 450px;">
        @csrf
        <div class="mb-3">
            <label for="fullname" class="form-label">Fullname</label>
            <input type="text" class="form-control" id="fullname" placeholder="Fullname" name="fullname" value="{{old('fullname')}}">
            <span>
                @error('fullname')
                    {{$message}}
                @enderror
            </span>
          </div>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" placeholder="Username" name="username" value="{{old('username')}}">
            <span>
                @error('username')
                    {{$message}}
                @enderror
            </span>
          </div>
          {{-- <div class="mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" class="form-control" id="email" placeholder="E-mail" name="email">
          </div> --}}
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" placeholder="Password" name="password">
            <span>
                @error('password')
                    {{$message}}
                @enderror
            </span>
          </div>
          <div>
            <button class="btn btn-primary mt-2">
                Submit
            </button>
          </div>
          <a href="{{route('loginformshow')}}">
              <h2 class= " mt-3">Already have Account!</h2>
          </a>
    </form>
</body>
</html>