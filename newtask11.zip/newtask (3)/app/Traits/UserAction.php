<?php
namespace App\Traits;

use App\Service\Interface\IUserService;

use Illuminate\Http\Request;

//use Illuminate\Support\Facades\Request;
use App\Helper\UserHelper;



trait UserAction
{
    public $userservice;

   // public $userHelper;
  //  public function __construct(IUserservice $userservice,UserHelper $userHelper)

    public function __construct(IUserservice $userservice)
    {
        $this->userservice = $userservice;
        
      //  $this->userHelper = $userHelper;

    }

    public function insert(Request $request)
    {
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password
        ];  
        return $this->userservice->insert($data);
    }


    public function display(Request $request)
    {
       
        return $this->userservice->showdis();
    }

    public function delete($id)
    {
        return $this->userservice->remove($id);
    }

    public function update(Request $request,$id)
    {
        
        $requ = [
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password
        ];  
        return $this->userservice->edit($requ,$id);
    }

   
}

