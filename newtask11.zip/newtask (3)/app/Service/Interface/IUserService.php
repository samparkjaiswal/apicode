<?php

namespace App\Service\Interface;

use Illuminate\Support\Facades\Request;


interface IUserService
{
    public function insert(array $request);

    public function showdis();

    public function remove($id);

    public function edit(array $requ,$id);

   
}