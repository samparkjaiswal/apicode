<?php
namespace App\Service;

use App\Service\Interface\IUserService;
use App\Repository\Interface\IUserRepository;
use Illuminate\Support\Facades\Request;
use App\Helper\UserHelper;
use PhpParser\Node\Expr\FuncCall;

class UserService implements IUserService
{
    public $userrepository;
   // public $userHelper;

   // public function __construct(IUserRepository $userrepository,UserHelper $userHelper)

    public function __construct(IUserRepository $userrepository)
    {
        $this->userrepository = $userrepository;

     //   $this->userHelper = $userHelper;
    }

    public function insert(array $request)
    {
      //  $data = $this->userHelper->User($request);

       return $this->userrepository->createUser($request);

    //   return response()->json(['UserService'=> $request], 200);


    }


    public function showdis()
    {
        return $this->userrepository->showdata();
    }

    public function remove($id)
    {
        return $this->userrepository->cutdata($id);
    }

    public function edit(array $requ,$id)
    {
        return $this->userrepository->updatedata($requ,$id);
    }
   
}

