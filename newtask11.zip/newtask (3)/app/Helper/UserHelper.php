<?php
namespace App\Helper;

use Illuminate\Http\Request;


// class UserHelper
// {
//     public function User(Request $request)
//     {
//         $data = [
//             'name' => $request->name,
//             'email' => $request->email,
//             'password' => $request->password
//         ];
//         return $data;
//     }
// }