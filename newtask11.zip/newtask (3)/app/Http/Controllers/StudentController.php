<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;

use App\Traits\UserAction;
use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    use UserAction;


}
