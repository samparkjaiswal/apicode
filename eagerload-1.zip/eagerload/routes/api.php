<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\CollegeController;
use App\Http\Controllers\MediaController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

// Route::get('/show/{id}',[OrderController::class,'order']);

//Route::get('/show/{id}',[OrderController::class,'ordernestedeagr']); //nested egerload works in laravel 9 

// Route::get('/show/{id}',[OrderController::class,'specificcolumn']);

//  Route::get('/show/{id}',[CollegeController::class,'withoutfunc']);

//  Route::get('/show/{id}',[CollegeController::class,'withonlyfn']);

//  Route::get('/show/{id}',[CollegeController::class,'constraineagerload']);

Route::get('/show/{id}',[MediaController::class, 'morphrel']);

