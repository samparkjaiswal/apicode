<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;

class CollegeController extends Controller
{
   
   
    public function withoutfunc($id)
    {
        $books = Book::without('student')->where('id',$id)->get();  //1-it use for if  we not want execute any relation function(pass function name in without method
        //2- In model where both function are implement, there define a array name of $with variable and pass function name which we want to excute)
      //  $books = Book::with(['classroom','student'])->where('id',$id)->get();
        return $books;
    }

    public function withonlyfn($id)
    {
        $books = Book::withOnly('student')->where('id',$id)->get();  //if we want to execute only specific relational function then pass name of relational function in withonly method it's return only these relation function data which fn name is pass in withonly method
        return $books;
    }

    public function constraineagerload($id)
    {
       

        $books = Book::with(['student' => function ($query) {
            $query->where('book_id', 'geeta');
        }])->where('id',$id)->get();
        return $books;

        // $books = Book::with(['student' => function ($query) {
        //     $query->orderBy('created_at', 'desc');  //for sorting and filtering of data this is best way
        // }])->where('id',$id)->get();
        // return $books;

        //if we want to execute relational function and also run a additional query then use this way
        //for this the with method where the array key is a relationship name (means array key name is relational function as(student who is relational function name in book model and here work as a array keyname))

       // note: The limit and take query builder methods may not be used when constraining eager loads.
    }

   
}
