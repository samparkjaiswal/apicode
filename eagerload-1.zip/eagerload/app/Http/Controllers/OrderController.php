<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shop;

class OrderController extends Controller
{
    // public function order($id)
    // {
    //     $data = Shop::with(['orders','product'])->where('id',$id)->get(); //eager loading two relation function call in one query run

    //     return $data;
    // }

    // public function ordernestedeager($id)
    // {
    //    // $data = Shop::with('neorder.neproduct')->where('id',$id)->get(); //nested eggar loading shopid in ordertable and orderid in product table and using dot(.) operation both model functions will be call for show data
      
    //     return $data;
    // }

    // public function ordernestedeagr($id)   //ask from sir  it's support laravel 9 version
    // {
    //     $data = Shop::with(
    //         [
    //             'neorder'=>[
    //                 'neproduct',
    //             ],
    //         ])->where('id',$id)->get();

    //         return $data;
    // }

    // public function specificcolumn($id)
    // {
    //     $data = Shop::with('orde:id,orderquantity,shop_id')->where('id',$id)->get(); //it's use for display specific column data(but foreign key will allways show if this column we ignore then it occur an error)
    //     return $data;
    // }


}
