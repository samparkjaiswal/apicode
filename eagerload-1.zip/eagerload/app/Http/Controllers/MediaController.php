<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Video;
use App\Models\Comment;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class MediaController extends Controller
{
    public function morphrel($id)
    {
       // $data = Post::with('comment')->where('id',$id)->get();
       // $data = Video::with('comment')->where('id',$id)->get();
       //return $data;
       $comments = Comment::with(['commentable' => function (MorphTo $morphTo) {
        $morphTo->constrain([
            Post::class => function (Builder $query) {
                $query->where('phone', 0);
            },
            Video::class => function (Builder $query) {
                $query->where('type', 1);
            },
        ]);
    }])->where('id',$id)->get();
        return $comments;
    }
}
