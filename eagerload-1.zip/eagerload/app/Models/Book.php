<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;
   // protected $table ='books';

   protected $with = ['classroom'];  //here $with is variable name who required and in this variable asssing a array and in this array define function name which we want to execute and it's work in without method correctly

    public function student()
    {
        return $this->hasMany(Student::class,'book_id','id');
    }

    public function classroom()
    {
        return $this->hasMany(Classroom::class, 'book_id' ,'id');
    }
}
