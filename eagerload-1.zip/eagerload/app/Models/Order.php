<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $table = 'orders';

    // public function neproduct()
    // {
    //     return $this->hasMany(Product::class,'order_id','id');
    // }
}
