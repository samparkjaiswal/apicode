<?php
namespace App\Helper;

use Illuminate\Http\Request;


class UserHelper
{
    public function User($request)
    {
       return  [
            'servicename' => $request->name,
            'serviceimage' => $request->image,
            'servicedescription' => $request->description
        ];
       
    }
}