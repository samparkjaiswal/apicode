<?php 
namespace App\Repository;


use App\Repository\GenericRepository;
use App\Repository\Interface\ICustomerRepository;

use App\Models\Customer;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;


class CustomerRepository extends GenericRepository implements ICustomerRepository
{
    public function model()
    {
        return Customer::class;
    }

    public function storeservice($data)
    {
       // dd(auth('api')->user()->id);

       $loginid = auth('api')->user()->id;
     //  dd($loginid);
     
       $que = [
        'servicename' => $data['name'],
               'serviceimage' => $data['image'],
              'servicedescription' => $data['description'],
              'userid' => $loginid,
             ];
       
        return $this->model->insert($que);
    }


    public function userservice()
    {
      
       $userid = auth('api')->user()->id;

     //  dd($userid);

        $code = $this->model->where('userid',$userid)->get();

      //  dd($code);

        return $code;
    }


    public function updateservice(array $editrow,$id)
    {
        
        $editdata = $this->model->find($id,'*');
      
        $data = $editdata->update($editrow);
       return $data;
    }



}