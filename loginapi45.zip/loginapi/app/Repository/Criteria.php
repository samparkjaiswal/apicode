<?php

namespace App\Repository;

use App\Repository\Interface\IGenericRepository;

abstract class Criteria
{

    /**
     * @param $model
     * @param Repository $repository
     * @return mixed
     */
    public abstract function apply($model, IGenericRepository $repository);
}
