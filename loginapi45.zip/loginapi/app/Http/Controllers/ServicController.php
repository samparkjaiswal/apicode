<?php

namespace App\Http\Controllers;

use App\Traits\UserAction;
use Illuminate\Http\Request;

class ServicController extends Controller
{
    use UserAction;
 
}
