<!doctype html>
<html lang="en">
  <head>
    <title>Display Data</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
      
    <div class="container">

      <!-- For Delete msg -->
      
        <?php if(session()->get('success')): ?>
        <div class="alert alert-success">
         <button type="button" class="close" data-bs-dismiss="alert">x</button>
         
         <?php echo e(session('success')); ?></div>
 
       <?php endif; ?>


       <?php if(session()->get('fail')): ?>
       <div class="alert alert-danger">
        <button type="button" class="close" data-bs-dismiss="alert">x</button>
        
        <?php echo e(session('fail')); ?></div>

      <?php endif; ?>





      <!--Update msg -->


      <?php if(session()->get('update')): ?>
      <div class="alert alert-success">
       <button type="button" class="close" data-bs-dismiss="alert">x</button>
       
       <?php echo e(session('update')); ?></div>

     <?php endif; ?>


     <?php if(session()->get('failed')): ?>
     <div class="alert alert-danger">
      <button type="button" class="close" data-bs-dismiss="alert">x</button>
      
      <?php echo e(session('failed')); ?></div>

    <?php endif; ?>


      
        <table class="table table-striped table-bordered table-hover">
            <pre>
                
            </pre>
            <thead class="thead-dark">
                <tr class="text-center">
                    <th>Name</th>
                    <th>Email</th>
                    <th>Qualification</th>
                    <th>Gender</th>
                    <th>Language</th>
                    <th colspan="2">Operation</th>
                </tr>
            </thead >
            <tbody>

               <?php $__currentLoopData = $cust; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                
                <tr class="text-center">
                    <td><?php echo e($customer->name); ?></td>
                    <td><?php echo e($customer->email); ?></td>
                    <td><?php echo e($customer->qualification); ?></td>
                    <td><?php echo e($customer->gender); ?></td>
                    <td><?php echo e($customer->language); ?></td>

                   

             <td><a href="<?php echo e(route('customer.fetch',['stdid'=>$customer->stdid])); ?>"><span class="fa fa-edit text-primary" style="font-size:20px"></span></a></td> 

                    
                
 
                 <td><a href="<?php echo e(route('customer.delete',['stdid'=>$customer->stdid])); ?>"><span class="fa fa-trash text-danger" style="font-size:20px"></span></a></td>



                  

            
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    

  </body>
</html><?php /**PATH /opt/lampp/htdocs/newtask/resources/views/show.blade.php ENDPATH**/ ?>