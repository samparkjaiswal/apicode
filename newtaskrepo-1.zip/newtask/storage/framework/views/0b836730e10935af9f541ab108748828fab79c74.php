<!doctype html>
<html lang="en">
  <head>
    <title>Updation</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
        <h1 class="text-center" style="">Updation Form</h1>

        <form action="<?php echo e(route('customer.update',['stdid'=>$edit->stdid])); ?>" method="post" autocomplete="off">



          <?php echo csrf_field(); ?>

      

        <div class="form-group">
          <label for="name">Name:</label>
          <input type="text" name="name" id="" class="form-control" placeholder="" value="<?php echo e($edit->name); ?>" aria-describedby="helpId">
          <span class="text-danger">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
        
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" id="" class="form-control" placeholder="" value="<?php echo e($edit->email); ?>" aria-describedby="helpId">
            <span class="text-danger">
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
          </div>

          
         
          <div class="form-group">
            <label for="cpass">Qualification:</label>
           
            <select name="qualification" id="" class="form-control">

                <option  type="hidden">Select Qualification</option> <!--Ternery Operator -->
                <option value="B.Tech" <?php echo e(($edit->qualification === 'B.Tech') ? 'Selected' : ''); ?>>B.Tech</option>

                <!-- <option value="B.Tech"

                <?php // if ($edit->qualification == 'B.Tech') {
                   // echo 'selected="selected"'; } ?>
                >B.Tech</option> -->

                <option value="M.Tech" <?php echo e(($edit->qualification === 'M.Tech') ? 'Selected' : ''); ?>>M.Tech</option>
               

            </select>
            <span class="text-danger">
              <?php $__errorArgs = ['qualifcation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
          </div>


          <div class="form-group">
            <label for="cpass">Gender:</label>
           <input type="radio" name="gender" value="male"  id=""
           <?php echo e(($edit->gender === 'male') ? 'Checked' : ''); ?>

           >Male
           <input type="radio" name="gender" value="female"  id=""
           <?php echo e(($edit->gender === 'female') ? 'Checked' : ''); ?>

           >Female
           
            <span class="text-danger">
              <?php $__errorArgs = ['qualifcation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
          </div>

          <?php
              $language = explode(',',$edit->language); //For change string into array formate
          ?>

          <div class="form-group">                          <!--  Use Ternery Operator For Fetch data and in_array function  -->
            <label for="cpass">Language Known:</label>
           <input type="checkbox" name="language[]" value="Hindi" <?php echo e(in_array('Hindi', $language) ? 'checked' : ''); ?>  id=""
        
           >Hindi
           <input type="checkbox" name="language[]" value="English" <?php echo e(in_array('English', $language) ? 'checked' : ''); ?> id=""
          
           >English
           
            <span class="text-danger">
              <?php $__errorArgs = ['qualifcation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
          </div>

          <button type="submit" class="btn btn-success">Update</button>

        </form>
    </div>  

    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    
  </body>
</html><?php /**PATH /opt/lampp/htdocs/newtask/resources/views/fetch.blade.php ENDPATH**/ ?>