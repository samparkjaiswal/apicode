<?php

namespace App\Service\interface;


interface IUserservice
{
    
}