<?php
namespace App\Repository;

use App\Repository\Interface\IUserrepository;

class Userrepository implements IUserrepository
{
    
}