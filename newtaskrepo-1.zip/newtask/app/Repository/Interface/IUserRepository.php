<?php

namespace App\Repository\Interface;

interface IUserrepository extends 
{

}