<?php
namespace App\Traits;

use App\Service\interface\IUserService;



trait UserAction
{
    private $userservice;

    public function __construct(IUserservice $userservice)
    {
        $this->userservice = $userservice;
    }
}