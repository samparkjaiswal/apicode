<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ServicController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });




// Route::get('/getall',[ServicController::class, 'getservice']);

// Route::post('/takeservice/{id}',[ServicController::class, 'utakeservice']);

// Route::get('/uviewservice',[ServicController::class, 'uviewservice']);

// Route::put('/ueditservice/{id}',[ServicController::class, 'ueditservice']);



Route::post('/uregister',[ServicController::class, 'uregister']);

Route::post('/ulogin',[ServicController::class, 'ulogin']);



Route::group(['middleware' => ['auth:api']], function () {

    Route::get('/getall',[ServicController::class, 'getservice']);

    Route::post('/takeservice/{id}',[ServicController::class, 'utakeservice']);
    
    Route::get('/uviewservice',[ServicController::class, 'uviewservice']);
    
    Route::put('/ueditservice/{id}',[ServicController::class, 'ueditservice']);

     Route::post('/ulogout',[ServicController::class, 'ulogout']);


});



