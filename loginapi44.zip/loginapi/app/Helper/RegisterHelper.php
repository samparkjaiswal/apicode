<?php
namespace App\Helper;

use Illuminate\Http\Request;


class RegisterHelper
{
    public function Userreg($request)
    {
       return  [
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password
        ];
       
    }
}