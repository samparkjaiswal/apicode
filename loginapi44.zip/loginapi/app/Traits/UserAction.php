<?php
namespace App\Traits;

use Illuminate\Http\Request;
use App\Helper\UserHelper;
use App\Service\Interface\IUserService;

use App\Http\Requests\V1\RegisterUserRequest;
use App\Http\Requests\V1\LoginUserRequest;



trait UserAction
{
    public $userservice;

 

    public function __construct(IUserService $userservice)
    {
        $this->userservice = $userservice;
    }

    public function getservice()
    {
       return $this->userservice->disservice();
    }

    
    public function utakeservice($id)
    {
        return $this->userservice->saveservice($id);
    }

    public function uviewservice()
    {
        return $this->userservice->view();
    }

    //public function ueditservice(Request $request,$id)
    public function ueditservice($id)
    {
       
        return $this->userservice->edit($id);
    }


    public function uregister(RegisterUserRequest $request)
    {
        
        return $this->userservice->insert($request);
    }
    
    public function ulogin(LoginUserRequest $request)
    {
        return $this->userservice->login($request);
    }

    public function ulogout(Request $request)
    {
        return $this->userservice->logout($request);
    }


    // public function save(Request $request)
    // {
    //     $data=[
    //         'name' => $request->name,
    //        'image' => $request->image,
    //         'description' => $request->description
    //     ];

    //     return $this->userservice->insert($data);
    // }
   
}

