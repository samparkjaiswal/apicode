<?php

namespace App\Service\Interface;

use Illuminate\Http\Request;

use App\Http\Requests\V1\RegisterUserRequest;
use App\Http\Requests\V1\LoginUserRequest;



interface IUserService
{
   public function disservice();

   public function saveservice($id);

   public function view();


   //public function edit(Request $request,$id);

   public function edit($id);

   public function insert(RegisterUserRequest $request);

   public function login(LoginUserRequest $request);

   public function logout(Request $request);

//    public function insert(array $data);
   
}