<?php
namespace App\Repository;

use App\Repository\GenericRepository;

use App\Repository\Interface\IRegisterRepository;

use App\Models\User;
use Illuminate\Http\Request;




class RegisterRepository extends GenericRepository implements IRegisterRepository
{
    public function model()
    {
        return User::class;
    }

    public function save(array $regi)
    {
        return $this->model->create($regi);
    }


    public function attemptauthemail($email, $password)
    {
        // dd($email,$password);
    

    $user = $this->where([
        'email' => $email,
        'password'=>$password
    ])->first();

    //dd($data);

    if (!$user) {
        
  

     $response =["message"=>"Wrong username or password!!"];
     return response($response,401);

       // return false;
    }
    else
    {
      
        
       $user->token = $user->createToken('Api access token')->accessToken;  //token generation
     
       return $user;
      
    //    $response =["message"=>"You have successfully logged in!!"];
    //     return response($response,200);

      
    }


  }


  public function userlogout(Request $request)
  {
    $token = $request->user()->token();

    $token->revoke();
    $response =["message"=>"You have successfully logout!!"];
    return response($response,200);
    
    //return $token;
  }




  

}