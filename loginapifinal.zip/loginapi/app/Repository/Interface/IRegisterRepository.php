<?php

namespace App\Repository\Interface;


use App\Repository\Interface\IGenericRepository;
use Illuminate\Http\Request;

interface IRegisterRepository extends IGenericRepository
{
    
    public function save(array $regi);
   
    public function attemptauthemail($email, $password);

    public function userlogout(Request $request);
  
}