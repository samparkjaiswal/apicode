<?php
namespace App\Repository;

use App\Repository\GenericRepository;
use App\Repository\Interface\IUserRepository;

use App\Models\Service;



class UserRepository extends GenericRepository implements IUserRepository
{
    public function model()
    {
        return Service::class;
    }




   public function disdata()
   {
   
        $show = $this->model->all('*');
     
        return $show;
   }


   public function insertservice($id)
   {
      return  $this->model->find($id);
       // dd($data);
      // return $data;

   }

//    public function ins(array $data)
//    {
//     return $this->model->create($data);
//    }

}