<?php

namespace App\Http\Controllers;

use App\Models\AlienComm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LoginStuff extends Controller
{
    public function show_login_form()
    {
        return view('loginform');
    }

    public function show_registeration_form()
    {
        return view('registerform');
    }

    public function welcome_page()
    {
        return view('welcome');
    }

    public function welcome_page_admin()
    {
        return view('welcomeadmin');
    }
    
    public function logout()
    {
        if(session()->has('loggeduser')){
            session()->pull('loggeduser');
            return redirect(route('loginformshow'));
        }
    }

}
