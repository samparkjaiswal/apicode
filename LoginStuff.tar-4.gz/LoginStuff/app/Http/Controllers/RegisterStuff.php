<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\AlienComm;

class RegisterStuff extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'fullname' => 'required',
            'username' => 'required|unique:aliencommunity',
            'password' => 'required|min:8|max:12'
        ]);

        // DB::table('aliencommunity')->insert([
        //     'fullname'=> $request['fullname'],
        //     'username'=> $request['username'],
        //     'password'=> $request['password']
        // ]);

        $create_user = new AlienComm;
        $create_user->fullname = $request['fullname'];
        $create_user->username = $request['username'];
        $create_user->password = $request['password'];
        $create_user->save();
        return view('loginform');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    public function show(Request $req)
    {
        $req->validate([
            'username' => 'required',
            'password' => 'required|min:8|max:12'
        ]);
        
        // $user = DB::table('aliencommunity')->where('username', $req['username'])->first();

        $user = new AlienComm;
        $user = AlienComm::where('username', $req['username'])->first();

        if(!$user){
            return view('registerform');
        }

        else {
            if($req['password'] === $user->password){
                $req->session()->put('loggeduser', $user->id);
                $req->session()->put('usertype', $user->usertype);
               return redirect('/welcome');
            }

            else {
                return view('loginform');
            }
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
        return view('forgotpassword');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required|min:8|max:12',
            'confirmpassword' => 'required|same:password',
        ]);

        // $user = DB::table('aliencommunity')->where('username', $request['username'])->first();
        $user = new AlienComm;
        $user= AlienComm::where('username', $request['username'])->first();

        if(!$user)
        {
            echo "User Not Found";
            return view('registerform');
        }
        else {
                // DB::table('aliencommunity')->where('username',$request['username'])->update(['password'=> $request['password']]);
                $user = AlienComm::where('username',$request['username'])->first();
                // echo $user->username;
                $user->password = $request['password'];
                $user->save();
                return view('loginform');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
