<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class Tokens
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
          
        if(session()->has('loggeduser'))
        {
            if (session('usertype') == 1) {
                // return view('welcomeadmin');
                return redirect(route('welcomepageadmin'));
            }
            else {
                // return redirect(route('welcomepage'));
                return redirect(route('welcomepage'));
            }
        }
        return $next($request);
    }
}
