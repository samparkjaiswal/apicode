<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginStuff;
use App\Http\Controllers\RegisterStuff;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/welcome', [LoginStuff::class, 'welcome_page'])->name('welcomepage')->middleware('tokenguard');
Route::get('/welcomeadmin', [LoginStuff::class, 'welcome_page_admin'])->name('welcomepageadmin')->middleware('tokenguard');

Route::get('/', [LoginStuff::class, 'show_login_form'])->name('loginformshow');
Route::post('/logincheck', [RegisterStuff::class, 'show'])->name('logincheck');
Route::get('/signupform', [LoginStuff::class, 'show_registeration_form'])->name('registerationformshow');
Route::post('/getdata', [RegisterStuff::class, 'store'])->name('storedata');
Route::get('/logoutuser', [LoginStuff::class, 'logout'])->name('logoutuser');
Route::get('/forgotpassword', [RegisterStuff::class, 'edit'])->name('forgotpassword');
Route::post('/forgotpassword', [RegisterStuff::class, 'update'])->name('getfgtpswrd');