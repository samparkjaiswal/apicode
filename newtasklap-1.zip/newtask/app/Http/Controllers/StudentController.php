<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;

use App\Traits\UserAction;
use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    
    use UserAction;
  
    
//     public function stuinsert(Request $request)
//     {
        
//         $rules=array(
//             "name"  =>"required",
//             "email" =>"required",
//             "password"=>"required"
            
//         );

//         $validator= Validator::make($request->all(),$rules);

     

//         if($validator->fails())
//         {
//            return $validator->errors();
         
//         }
//         else
//         {
//         $student = new Student;

//         $student->name = $request->name;
//         $student->email = $request->email;
//         $student->password = $request->password;

//         $student->save();
//         return response()->json($student);
//         }
//     }

//     public function show()
//     {
//        $student =Student::all();
//         return response()->json($student);
//     }

//    // public function update(Request $request,$id) 

//      public function update(Request $request,$stdid)
//     {

//        //  $students = Student::where('id',$id)->first(); //work only if primaryKey name(column name) is id(other name is not expected)

//     //    $students = Student::find($id);  //it's also work if coloumn name(primarykey) is id(other name is not expected)

//     //     $students->name = $request->name;
//     //     $students->email = $request->email;
//     //     $students->password = $request->password;

//     //     $students->save();
//     //     return response()->json($students);

//         // $student = Student::find($request->id); //if column name is id(not other name) and id given by user input in api

//         // $student->name=$request->name;
//         // $student->email=$request->email;
//         // $student->password=$request->password;

//         // $data = $student->save();
//         // return response()->json($data);

       
//     $student = Student::where('stdid',$stdid);
//     $student->update($request->all());

//     return response()->json($student);

//     }







//     public function delete($stdid)
//     {
//         $student = Student::where('stdid',$stdid)->delete();

//         return response()->json($student);
    
//     }

    
}
