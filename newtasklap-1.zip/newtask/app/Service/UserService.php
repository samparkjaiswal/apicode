<?php

use App\Service\interface\IUserservice;
use App\Repository\Interface\IUserRepository;

class Userservice implements IUserservice
{
    private $userrepository;

    public function __construct(IUserRepository $userrepository)
    {
        $this->userrepository =$userrepository;
    }

   
}