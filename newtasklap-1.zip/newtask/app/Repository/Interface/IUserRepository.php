<?php

namespace App\Repository\Interface;


use App\Repository\Interface\IGenericRepository;

interface IUserRepository extends IGenericRepository
{

}