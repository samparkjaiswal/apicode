<?php
namespace App\Repository;

use App\Repository\GenericRepository;
use App\Repository\Interface\IUserRepository;

use App\Models\Student;


class UserRepository extends GenericRepository implements IUserRepository
{
    public function model()
    {
        return Student::class;
    }
}