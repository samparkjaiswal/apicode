<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

//use App\Service\interface\IUserservice;

use App\Repository\Interface\IUserrepository;
use App\Repository\Userrepository;


class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(IUserrepository::class, Userrepository::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
