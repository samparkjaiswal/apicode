<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomerController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware(['logincheck'])->group(function () {

    Route::get('/customer/home', [CustomerController::class, 'cuhome'])->name('customer.home');

Route::get('/admin/dash', [CustomerController::class, 'dash'])->name('admin.dash');
   
    });



Route::get('/customer/reg', [CustomerController::class, 'cureg'])->name('customer.reg');

Route::get('/customer/login', [CustomerController::class, 'culogin'])->name('customer.login');

// Route::get('/customer/home', [CustomerController::class, 'cuhome'])->name('customer.home');

// Route::get('/admin/dash', [CustomerController::class, 'dash'])->name('admin.dash');


Route::post('/customer/reg', [CustomerController::class, 'cuinsert'])->name('customer.insert');

Route::post('/customer/login', [CustomerController::class, 'login'])->name('cus.login');

Route::get('logout', [CustomerController::class, 'logout'])->name('logout');

Route::get('/admin/addproduct', [CustomerController::class, 'addproduct'])->name('admin.product');

Route::get('/admin/disproduct', [CustomerController::class, 'displayproduct'])->name('admin.disproduct');

Route::post('/admin/addproduct', [CustomerController::class, 'insertproduct'])->name('insert.product');