<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Product;

class CustomerController extends Controller
{
    public function cureg()
    {
        return view('/customer/customerreg');
    }

    public function culogin()
    {
        return view('/customer/customerlogin');
    }

    public function cuhome()
    {
        return view('/customer/home');
    }

    public function dash()
    {
        return view('/admin/dash');
    }

    public function addproduct()
    {
       return view('/admin/addproduct');
    }


    public function cuinsert(Request $request)
    {
        // $request->validate([

        //     'name' => 'required',
        //     'email' => 'required|email|unique:customers',
        //     'password' => 'required|min:5|max:12',
        //     'mobile' => 'required|min:10|max:12',
        //     'address' => 'required'
    
        //    ]);

           $customer = new Customer;

           $customer->name = $request->name;
           $customer->email = $request->email;
           $customer->password = $request->password;
           $customer->mobile = $request->mobile;
           $customer->address = $request->address;
            $customer->save();

    }

    public function login(Request $request)
    {
        //print_r($_POST); //for console check

        $customer = Customer::where('email','=',$request->email)->first();
        
       // print_r($customer);
       
        if($customer)
        {
           // echo "hellow";
          if($request->password == $customer->password)
          {
           // echo "hellow";
            $request->session()->put('Loginid',$customer->id);
            $request->session()->put('Name',$customer->name);
            $request->session()->put('role',$customer->role);
            //return redirect(route('admin.dash'));
          }
        }
      
     }


     public function logout()
     {
        if(session()->has('Loginid'))
        {
            session()->pull('Loginid');
            return redirect(route('customer.home'));
        }
     }

     public function insertproduct(Request $request)
     {
        $product = new Product;

        $product->productname = $request->pname;
        $product->file = $request->file->store('upload');
        $product->save();
     }

     public function displayproduct()
     {
        $product = Product::all();
        return response()->json([
            'product' => $product,
        ]);
        
     }

    
}
