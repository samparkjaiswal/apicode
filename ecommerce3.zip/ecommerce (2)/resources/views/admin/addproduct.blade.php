@extends('admin.dash')

@section('content')




<div class="container">

    <div class="row" style="margin-top:50px">

        <div class="col-md-6">

            <div class="card">
                <div class="card-header bg-primary text-white">Add New Product</div>
                    <div class="card-body">

                        <form id="addproduct" autocomplete="off" method="POST" enctype="multipart/form-data">
                            @csrf

                            <div class="form-group">
                              <label for="">Product Name</label>
                              <input type="text" name="pname" id="pname" class="form-control" placeholder="Enter product name" aria-describedby="helpId">  
                            </div>
                    
                            <div class="form-group">
                                <label for="">Upload File</label>
                                <input type="file" name="file" id="" class="form-control" placeholder="Enter name" aria-describedby="helpId">
                            </div>

                                <button type="submit" class="btn btn-success">Save Product</button>
                    
                        </form>

                    </div>
                
            </div>

       
        </div>

         <div class="col-md-6">

            <div class="card">
                <div class="card-header bg-warning text-white">All Products</div>
                <div class="card-body">

                    

                    
                        <table>
                            <thead>
                                <tr>
                                    <th>Product_Id</th>
                                    <th>Name</th>
                                    <th>File</th>
                                </tr>
                            </thead>

                            <tbody>
                               
                                    
                                
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        
                                    </td>
                                </tr>
                                
                            </tbody>
                        </table>


                    

                </div>
            </div>

        </div>
    </div>
</div>












@endsection



<script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>







<script>
    $(document).ready(function(){

        fetchproduct();

        function fetchproduct()
        {
            $.ajax({
                type: "GET",
                url:"/admin/disproduct",
                dataType: "json",
                success:function(response){
                    console.log(response.product);

                }
            })
        }



        $('#addproduct').submit(function(e){

            e.preventDefault();
            
            let formdata = new FormData($('#addproduct')[0]);

            $.ajax({
                type: "POST",
                url: "/admin/addproduct",
                data: formdata,
                contentType:false,
                processData:false,
                success: function (response) {
                console.log(response);
                alert('Product Add');
                },
                error:function(error){
                console.log(error);
                alert('Product Not Add');
          }
            });

        });
    });
</script>

{{--Form Data function in Ajax
     The jQuery Ajax formData is set up the key and values of the given form and sends value using the jQuery Ajax method.
The jQuery Ajax formData is a method to provide form values like text, number, images, and files and upload on the URL sever.
The jQuery Ajax formData is a function to create a new object and send multiple files using this object.
The jQuery Ajax FormData is a method to setup “multipart/ form-data” and upload on server using XMLHttpRequest.
The jQuery Ajax formData is a constructor to interconnect form data with the server using Ajax HTTP request.
The jQuery Ajax formData is a function to create form information and work on it.
The jQuery Ajax formData is a operate form data like insert, delete, and retrieve, and so on.
The jQuery Ajax formData is supported to interact between server and user using form data. --}}


{{-- Content type
    the jQuery ajax contenttype is used to specifies that the type of data sending to the server. The jQuery ajax contenttype option is a built-in option that is passed to the ajax() function in the jQuery. The contenttype option is also called as MIME (multipurpose internet mail extension) type, it includes an HTTP header that specifies the information about what kind of data we are sending to the server. --}}


{{-- If you explicitly pass in a content-type to $.ajax(), then it is always sent to the server (even if no data is sent). As of jQuery 1.6 you can pass false to tell jQuery to not set any content type header. --}}

{{-- MIME stands for Multipurpose Internet Mail Extensions.It is a fundamental part of communication protocols such as HTTP. The MIME type is required when you need to transfer non-text data. MIME was originally designed to extend the capabilities of email to support more data types such as non-ASCII text files and binary files such as images, PDFs, and executables. --}}

{{-- It is often referred to as a media type or MIME content type --}}


{{--Process Data
     If set to false it stops jQuery processing any of the data. In other words if processData is false jQuery simply sends whatever you specify as data in an Ajax request without any attempt to modify it by encoding as a query string. --}}




   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

